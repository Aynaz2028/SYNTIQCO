-- HabitFirst V1 — Smart Retention Alerts support
-- Stores Web Push subscriptions per student so the retention-alert cron
-- job can notify them when a memory-engine concept is due for revision.

create table if not exists public.push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students (id) on delete cascade,
  endpoint text not null unique,
  p256dh text not null,
  auth text not null,
  created_at timestamptz not null default now()
);

create index if not exists push_subscriptions_student_idx on public.push_subscriptions (student_id);

alter table public.push_subscriptions enable row level security;

create policy "push_subscriptions_all_own" on public.push_subscriptions for all
  using (auth.uid() = student_id) with check (auth.uid() = student_id);

-- ============================================================
-- Notification phone number — SMS is stubbed in V1 (no provider wired
-- yet), but we capture the field now so the V2 MFS-region SMS provider
-- integration doesn't need another migration + UI round trip.
-- ============================================================
alter table public.students
  add column if not exists notification_phone text;

-- ============================================================
-- Track the last time we alerted a student about a given weak point,
-- so the cron job doesn't re-notify every run for the same due concept.
-- ============================================================
alter table public.weak_points
  add column if not exists last_alerted_at timestamptz;
