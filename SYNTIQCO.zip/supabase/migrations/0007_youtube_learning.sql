-- HabitFirst — YouTube Learning (Paste Link -> Summary -> Quiz Generation)
-- Run this in the Supabase SQL editor (or via `supabase db push`).

-- ============================================================
-- YOUTUBE LESSONS — one row per pasted video: the AI-generated summary,
-- key points, and comprehension quiz, plus per-question results so a quiz
-- answer can be logged without regenerating the quiz.
-- ============================================================
create table if not exists public.youtube_lessons (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students (id) on delete cascade,
  video_id text not null,
  video_url text not null,
  title text not null,
  thumbnail_url text,
  subject text not null default 'General',
  summary text not null,
  key_points text[] not null default '{}',
  quiz jsonb not null default '[]', -- [{ question, choices, answerIndex }]
  quiz_results jsonb not null default '{}', -- { "0": true, "1": false, ... } keyed by question index
  created_at timestamptz not null default now()
);

create index if not exists youtube_lessons_student_idx
  on public.youtube_lessons (student_id, created_at desc);

-- ============================================================
-- SERVER-SIDE RATE LIMITING (freemium enforcement) — one row per student
-- per day, incremented once per pasted link analyzed.
-- ============================================================
create table if not exists public.youtube_usage (
  student_id uuid not null references public.students (id) on delete cascade,
  usage_date date not null,
  use_count int not null default 0,
  primary key (student_id, usage_date)
);

-- ============================================================
-- weak_points can now be sourced from YouTube Learning too.
-- ============================================================
alter table public.weak_points drop constraint if exists weak_points_source_check;
alter table public.weak_points
  add constraint weak_points_source_check
  check (source in ('quiz', 'solver', 'mcq', 'flashcard', 'practice', 'youtube'));

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
alter table public.youtube_lessons enable row level security;
alter table public.youtube_usage enable row level security;

create policy "youtube_lessons_all_own" on public.youtube_lessons for all
  using (auth.uid() = student_id) with check (auth.uid() = student_id);

create policy "youtube_usage_all_own" on public.youtube_usage for all
  using (auth.uid() = student_id) with check (auth.uid() = student_id);
