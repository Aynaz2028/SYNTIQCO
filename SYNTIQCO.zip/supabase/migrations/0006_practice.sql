-- HabitFirst — Practice (MCQ + Written Answer with Instant AI Feedback)
-- Run this in the Supabase SQL editor (or via `supabase db push`).

-- ============================================================
-- PRACTICE ATTEMPTS — student-directed practice, distinct from the
-- daily mission's auto-picked steps. Covers both modes:
--   mode = 'mcq'     -> is_correct set, marks_* / feedback null
--   mode = 'written' -> marks_awarded/max_marks/feedback set from AI grading
-- ============================================================
create table if not exists public.practice_attempts (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students (id) on delete cascade,
  subject text not null,
  topic text not null,
  subtopic text,
  mode text not null check (mode in ('mcq', 'written')),
  question text not null,
  written_answer text,
  marks_awarded int,
  max_marks int,
  feedback text,
  is_correct boolean,
  created_at timestamptz not null default now()
);

create index if not exists practice_attempts_student_idx
  on public.practice_attempts (student_id, created_at desc);

-- ============================================================
-- SERVER-SIDE RATE LIMITING (freemium enforcement) — one row per
-- student per day, incremented once per generated question (either mode).
-- ============================================================
create table if not exists public.practice_usage (
  student_id uuid not null references public.students (id) on delete cascade,
  usage_date date not null,
  use_count int not null default 0,
  primary key (student_id, usage_date)
);

-- ============================================================
-- weak_points can now be sourced from Practice too.
-- ============================================================
alter table public.weak_points drop constraint if exists weak_points_source_check;
alter table public.weak_points
  add constraint weak_points_source_check
  check (source in ('quiz', 'solver', 'mcq', 'flashcard', 'practice'));

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
alter table public.practice_attempts enable row level security;
alter table public.practice_usage enable row level security;

create policy "practice_attempts_all_own" on public.practice_attempts for all
  using (auth.uid() = student_id) with check (auth.uid() = student_id);

create policy "practice_usage_all_own" on public.practice_usage for all
  using (auth.uid() = student_id) with check (auth.uid() = student_id);
