-- Subscription (item 15): adds the VIP tier alongside Free/Pro, a
-- tier_expires_at so a paid tier lapses back to Free automatically once its
-- period ends (see effectiveTier() in src/lib/tiers.ts), and a
-- subscription_payments table that tracks UddoktaPay checkout attempts —
-- the callback/webhook routes look a payment up by it to know which
-- student + tier a given invoice_id was for.

do $$
begin
  if exists (
    select 1 from pg_constraint where conname = 'students_tier_check'
  ) then
    alter table students drop constraint students_tier_check;
  end if;
end $$;

alter table students
  add constraint students_tier_check check (tier in ('free', 'pro', 'vip'));

alter table students
  add column if not exists tier_expires_at timestamptz;

create table if not exists subscription_payments (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references students (id) on delete cascade,
  tier text not null check (tier in ('pro', 'vip')),
  amount numeric(10, 2) not null,
  payment_method text,
  gateway text not null default 'uddoktapay',
  invoice_id text unique,
  status text not null default 'pending' check (status in ('pending', 'completed', 'failed', 'cancelled')),
  transaction_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists subscription_payments_student_id_idx
  on subscription_payments (student_id);

-- Students only ever need to see their own payment attempts (Subscription
-- screen shows current status); everything else — creating rows, marking
-- them completed — goes through the service-role client from the checkout/
-- callback/webhook routes, same pattern as the existing cron tables.
alter table subscription_payments enable row level security;

create policy "Students can view their own payments"
  on subscription_payments for select
  using (auth.uid() = student_id);
