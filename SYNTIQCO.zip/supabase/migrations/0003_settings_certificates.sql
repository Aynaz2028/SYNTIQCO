-- HabitFirst — Settings & Profile (certificates) schema
-- Run this in the Supabase SQL editor (or via `supabase db push`).

-- ============================================================
-- STUDENT SETTINGS — theme, language, privacy prefs
-- ============================================================
create table if not exists public.student_settings (
  student_id uuid primary key references public.students (id) on delete cascade,
  theme text not null default 'dark' check (theme in ('dark', 'light', 'system')),
  language text not null default 'en' check (language in ('en', 'bn')),
  show_on_leaderboard boolean not null default true,
  share_progress_with_friends boolean not null default false,
  updated_at timestamptz not null default now()
);

alter table public.student_settings enable row level security;

create policy "student_settings_all_own" on public.student_settings for all
  using (auth.uid() = student_id) with check (auth.uid() = student_id);

-- ============================================================
-- CERTIFICATES — awarded automatically when a subject's memory
-- engine backlog is fully cleared (see lib/profile-stats.ts)
-- ============================================================
create table if not exists public.certificates (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students (id) on delete cascade,
  subject text not null,
  title text not null,
  issued_at timestamptz not null default now(),
  unique (student_id, subject, title)
);

create index if not exists certificates_student_idx on public.certificates (student_id, issued_at desc);

alter table public.certificates enable row level security;

create policy "certificates_select_own" on public.certificates for select
  using (auth.uid() = student_id);

-- Certificates are only ever inserted by the authenticated user's own
-- request-scoped client (never client-editable afterwards — no update policy).
create policy "certificates_insert_own" on public.certificates for insert
  with check (auth.uid() = student_id);
