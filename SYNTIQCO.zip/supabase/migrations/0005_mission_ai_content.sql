-- HabitFirst — Daily Mission: AI-generated Flashcard + Weak Topic Review content
-- Run this in the Supabase SQL editor (or via `supabase db push`).

-- Flashcard step used to just show the weak point's subject/topic name and ask
-- "did you remember it" with nothing to actually recall. flashcard_ref stores
-- the real AI-generated { front, back } card content instead.
alter table public.daily_missions
  add column if not exists flashcard_ref jsonb;

-- New 4th mission step: a short AI-generated re-teach note ({ summary,
-- commonMistake, example }) on the student's single highest-priority weak
-- topic, shown before the matching quiz question (quiz_weak_point_id).
alter table public.daily_missions
  add column if not exists review_ref jsonb;

comment on column public.daily_missions.completed_steps is
  'subset of {''review'',''flashcard'',''quiz'',''mcq''}';
