-- HabitFirst — AI Tutor + Chat schema
-- Run this in the Supabase SQL editor (or via `supabase db push`).

-- ============================================================
-- TUTORS — a student can create several, each with its own persona
-- ============================================================
create table if not exists public.tutors (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students (id) on delete cascade,
  name text not null check (char_length(name) between 1 and 40),
  subject text not null,
  personality text not null default 'encouraging'
    check (personality in ('encouraging', 'strict', 'funny', 'socratic')),
  voice text not null default 'neutral' check (voice in ('female', 'male', 'neutral')),
  avatar text not null default '🦉',
  language text not null default 'en' check (language in ('en', 'bn')),
  created_at timestamptz not null default now()
);

create index if not exists tutors_student_idx on public.tutors (student_id, created_at desc);

-- ============================================================
-- CHAT MESSAGES — full transcript per tutor
-- ============================================================
create table if not exists public.chat_messages (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students (id) on delete cascade,
  tutor_id uuid not null references public.tutors (id) on delete cascade,
  role text not null check (role in ('user', 'assistant')),
  content text not null,
  had_image boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists chat_messages_tutor_idx on public.chat_messages (tutor_id, created_at asc);

-- ============================================================
-- CHAT RATE LIMITING (freemium enforcement, mirrors solver_usage)
-- ============================================================
create table if not exists public.chat_usage (
  student_id uuid not null references public.students (id) on delete cascade,
  usage_date date not null,
  use_count int not null default 0,
  primary key (student_id, usage_date)
);

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
alter table public.tutors enable row level security;
alter table public.chat_messages enable row level security;
alter table public.chat_usage enable row level security;

create policy "tutors_all_own" on public.tutors for all
  using (auth.uid() = student_id) with check (auth.uid() = student_id);

create policy "chat_messages_all_own" on public.chat_messages for all
  using (auth.uid() = student_id) with check (auth.uid() = student_id);

create policy "chat_usage_all_own" on public.chat_usage for all
  using (auth.uid() = student_id) with check (auth.uid() = student_id);
