-- Notifications (item 14): AI Reminder / Daily Mission / Friend Activity
-- preference toggles, plus a small guard table so the Daily Mission
-- reminder cron (which runs hourly across timezones) never double-sends
-- to the same student on the same local day.

alter table student_settings
  add column if not exists ai_reminder_notifications boolean not null default true,
  add column if not exists daily_mission_notifications boolean not null default true,
  -- No Friends feature exists yet — this column just captures the
  -- preference now so it's ready to gate real sends once Friends ships.
  add column if not exists friend_activity_notifications boolean not null default true;

create table if not exists mission_reminders_sent (
  student_id uuid not null references students (id) on delete cascade,
  reminder_date date not null,
  sent_at timestamptz not null default now(),
  primary key (student_id, reminder_date)
);
