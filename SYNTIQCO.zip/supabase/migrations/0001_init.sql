-- HabitFirst V1 schema
-- Run this in the Supabase SQL editor (or via `supabase db push`).

create extension if not exists vector;
create extension if not exists pgcrypto;

-- ============================================================
-- STUDENTS (extends auth.users)
-- ============================================================
create table if not exists public.students (
  id uuid primary key references auth.users (id) on delete cascade,
  full_name text,
  curriculum_track text check (curriculum_track in ('nctb', 'cambridge_edexcel')),
  curriculum_level text, -- 'ssc' | 'hsc' | 'o_level' | 'a_level'
  subjects text[] not null default '{}',
  tier text not null default 'free' check (tier in ('free', 'pro')),
  timezone text not null default 'Asia/Dhaka',
  onboarding_completed_at timestamptz,
  created_at timestamptz not null default now()
);

-- ============================================================
-- WEAK POINTS — the Knowledge Memory Engine's core table
-- ============================================================
create table if not exists public.weak_points (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students (id) on delete cascade,
  subject text not null,
  topic text not null,
  subtopic text,
  error_type text not null check (error_type in ('wrong_answer', 'skipped_step', 'conceptual_gap')),
  source text not null default 'quiz' check (source in ('quiz', 'solver', 'mcq', 'flashcard')),
  -- decay_score: 1.0 = freshly wrong / fully "owed" revision, decays toward 0 as it's reviewed & retained
  decay_score numeric not null default 1.0,
  times_reviewed int not null default 0,
  last_reviewed_at timestamptz,
  embedding vector(768), -- text-embedding-004 dimension; store null until embedding job runs
  created_at timestamptz not null default now()
);

create index if not exists weak_points_student_idx on public.weak_points (student_id, created_at desc);
create index if not exists weak_points_decay_idx on public.weak_points (student_id, decay_score desc);
-- ivfflat needs data to build well; safe to create, Postgres will just use seq scan until populated
create index if not exists weak_points_embedding_idx on public.weak_points
  using ivfflat (embedding vector_cosine_ops) with (lists = 100);

-- ============================================================
-- DAILY MISSIONS
-- ============================================================
create table if not exists public.daily_missions (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students (id) on delete cascade,
  mission_date date not null, -- student-local calendar day
  flashcard_weak_point_id uuid references public.weak_points (id) on delete set null,
  quiz_weak_point_id uuid references public.weak_points (id) on delete set null,
  quiz_ref jsonb, -- generated MCQ targeting quiz_weak_point_id's exact topic
  mcq_ref jsonb, -- { subject, topic, question, choices, answer_index } - generated, no separate bank table in V1
  completed_steps text[] not null default '{}', -- subset of {'flashcard','quiz','mcq'}
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  unique (student_id, mission_date)
);

create index if not exists daily_missions_student_date_idx on public.daily_missions (student_id, mission_date desc);

-- ============================================================
-- STREAKS
-- ============================================================
create table if not exists public.streaks (
  student_id uuid primary key references public.students (id) on delete cascade,
  current_streak int not null default 0,
  longest_streak int not null default 0,
  last_completed_date date,
  badges text[] not null default '{}', -- e.g. {'7_day','14_day','30_day'}
  updated_at timestamptz not null default now()
);

-- ============================================================
-- QUIZ / SOLVER LOGS
-- ============================================================
create table if not exists public.quiz_logs (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students (id) on delete cascade,
  subject text not null,
  topic text not null,
  subtopic text,
  question text not null,
  is_correct boolean not null,
  created_at timestamptz not null default now()
);

create table if not exists public.solver_logs (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students (id) on delete cascade,
  subject text,
  topic text,
  question_text text not null,
  input_type text not null default 'typed' check (input_type in ('typed', 'photo')),
  was_first_attempt_wrong boolean not null default false,
  response_steps jsonb,
  created_at timestamptz not null default now()
);

-- ============================================================
-- SERVER-SIDE RATE LIMITING (freemium enforcement)
-- ============================================================
create table if not exists public.solver_usage (
  student_id uuid not null references public.students (id) on delete cascade,
  usage_date date not null,
  use_count int not null default 0,
  primary key (student_id, usage_date)
);

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
alter table public.students enable row level security;
alter table public.weak_points enable row level security;
alter table public.daily_missions enable row level security;
alter table public.streaks enable row level security;
alter table public.quiz_logs enable row level security;
alter table public.solver_logs enable row level security;
alter table public.solver_usage enable row level security;

create policy "students_select_own" on public.students for select using (auth.uid() = id);
create policy "students_update_own" on public.students for update using (auth.uid() = id);
create policy "students_insert_own" on public.students for insert with check (auth.uid() = id);

create policy "weak_points_all_own" on public.weak_points for all
  using (auth.uid() = student_id) with check (auth.uid() = student_id);

create policy "daily_missions_all_own" on public.daily_missions for all
  using (auth.uid() = student_id) with check (auth.uid() = student_id);

create policy "streaks_all_own" on public.streaks for all
  using (auth.uid() = student_id) with check (auth.uid() = student_id);

create policy "quiz_logs_all_own" on public.quiz_logs for all
  using (auth.uid() = student_id) with check (auth.uid() = student_id);

create policy "solver_logs_all_own" on public.solver_logs for all
  using (auth.uid() = student_id) with check (auth.uid() = student_id);

create policy "solver_usage_all_own" on public.solver_usage for all
  using (auth.uid() = student_id) with check (auth.uid() = student_id);

-- ============================================================
-- Helper: cluster related weak points by embedding cosine distance
-- (e.g. grouping several kinematics sub-errors together)
-- ============================================================
create or replace function public.match_weak_points(
  p_student_id uuid,
  p_weak_point_id uuid,
  p_match_count int default 5
)
returns table (
  id uuid,
  subject text,
  topic text,
  subtopic text,
  similarity float
) as $$
  select
    wp.id,
    wp.subject,
    wp.topic,
    wp.subtopic,
    1 - (wp.embedding <=> src.embedding) as similarity
  from public.weak_points wp
  join public.weak_points src on src.id = p_weak_point_id
  where wp.student_id = p_student_id
    and wp.id <> p_weak_point_id
    and wp.embedding is not null
    and src.embedding is not null
  order by wp.embedding <=> src.embedding
  limit p_match_count;
$$ language sql stable security definer;

-- ============================================================
-- Helper: bump decay score down on review, and mark reviewed
-- ============================================================
create or replace function public.review_weak_point(p_weak_point_id uuid, p_retained boolean)
returns void as $$
begin
  update public.weak_points
  set
    times_reviewed = times_reviewed + 1,
    last_reviewed_at = now(),
    decay_score = case
      when p_retained then greatest(decay_score - 0.35, 0.05)
      else least(decay_score + 0.15, 1.0)
    end
  where id = p_weak_point_id;
end;
$$ language plpgsql security definer;
