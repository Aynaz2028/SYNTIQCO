"use client";

import { useMemo } from "react";
import katex from "katex";
import "katex/dist/katex.min.css";

function render(math: string, displayMode: boolean) {
  try {
    return katex.renderToString(math, {
      throwOnError: false,
      displayMode,
    });
  } catch {
    return math;
  }
}

export function InlineMath({ math }: { math: string }) {
  const html = useMemo(() => render(math, false), [math]);
  return <span dangerouslySetInnerHTML={{ __html: html }} />;
}

export function BlockMath({ math }: { math: string }) {
  const html = useMemo(() => render(math, true), [math]);
  return <div dangerouslySetInnerHTML={{ __html: html }} />;
}
