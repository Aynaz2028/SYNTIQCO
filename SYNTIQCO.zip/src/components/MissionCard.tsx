"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/Button";
import { MarginMark } from "@/components/MarginMark";

interface QuizRef {
  subject: string;
  topic: string;
  question: string;
  choices: string[];
  answerIndex: number;
}

interface FlashcardRef {
  subject: string;
  topic: string;
  front: string;
  back: string;
}

interface ReviewRef {
  subject: string;
  topic: string;
  summary: string;
  commonMistake: string;
  example: string;
}

interface WeakPointRef {
  id: string;
  subject: string;
  topic: string;
  subtopic: string | null;
}

interface Mission {
  id: string;
  flashcard_weak_point_id: string | null;
  quiz_weak_point_id: string | null;
  review_ref: ReviewRef | null;
  flashcard_ref: FlashcardRef | null;
  quiz_ref: QuizRef | null;
  mcq_ref: QuizRef | null;
  completed_steps: string[];
}

type Step = "review" | "flashcard" | "quiz" | "mcq";

export function MissionCard({ onAllDone }: { onAllDone: (streak: unknown) => void }) {
  const [mission, setMission] = useState<Mission | null>(null);
  const [weakPointsById, setWeakPointsById] = useState<Record<string, WeakPointRef>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/mission/today")
      .then(async (res) => {
        if (!res.ok) throw new Error((await res.json()).error ?? "Failed to load mission");
        return res.json();
      })
      .then((data) => {
        setMission(data.mission);
        setWeakPointsById(data.weakPointsById);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  async function completeStep(step: Step, payload: Record<string, unknown>) {
    if (!mission) return;
    const res = await fetch("/api/mission/complete", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ missionId: mission.id, step, ...payload }),
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error ?? "Something went wrong");
      return;
    }
    setMission({ ...mission, completed_steps: data.completedSteps });
    if (data.allDone) onAllDone(data.streak);
  }

  if (loading) return <p className="text-sm text-paper/60">Loading today&apos;s mission…</p>;
  if (error) return <p className="text-sm text-red">{error}</p>;
  if (!mission) return null;

  const done = new Set(mission.completed_steps);
  const flashcardWP = mission.flashcard_weak_point_id
    ? weakPointsById[mission.flashcard_weak_point_id]
    : null;
  const reviewWP = mission.quiz_weak_point_id ? weakPointsById[mission.quiz_weak_point_id] : null;

  return (
    <div className="space-y-4">
      <ReviewStep
        weakPoint={reviewWP}
        review={mission.review_ref}
        isDone={done.has("review")}
        onDone={() => completeStep("review", { weakPointId: mission.quiz_weak_point_id ?? null })}
      />
      <FlashcardStep
        flashcard={mission.flashcard_ref}
        isDone={done.has("flashcard")}
        onAnswer={(retained) =>
          completeStep("flashcard", { weakPointId: flashcardWP?.id ?? null, retained })
        }
      />
      <QuizStep
        title="Weak Topic Quiz"
        markLabel="M1"
        quiz={mission.quiz_ref}
        isDone={done.has("quiz")}
        onAnswer={(isCorrect) =>
          completeStep("quiz", {
            weakPointId: mission.quiz_weak_point_id,
            isCorrect,
            subject: mission.quiz_ref?.subject,
            topic: mission.quiz_ref?.topic,
            question: mission.quiz_ref?.question,
          })
        }
      />
      <QuizStep
        title="Past Paper MCQ"
        markLabel="A1"
        quiz={mission.mcq_ref}
        isDone={done.has("mcq")}
        onAnswer={(isCorrect) =>
          completeStep("mcq", {
            isCorrect,
            subject: mission.mcq_ref?.subject,
            topic: mission.mcq_ref?.topic,
            question: mission.mcq_ref?.question,
          })
        }
      />
    </div>
  );
}

function StepShell({
  markLabel,
  title,
  isDone,
  children,
}: {
  markLabel: string;
  title: string;
  isDone: boolean;
  children: React.ReactNode;
}) {
  return (
    <div className="paper rounded-sm p-5">
      <div className="flex items-center gap-3">
        <MarginMark label={markLabel} variant={isDone ? "green" : "red"} />
        <h3 className="font-display text-lg">{title}</h3>
        {isDone && <span className="ml-auto font-mono text-xs text-green">done</span>}
      </div>
      {!isDone && <div className="mt-4">{children}</div>}
    </div>
  );
}

function ReviewStep({
  weakPoint,
  review,
  isDone,
  onDone,
}: {
  weakPoint: WeakPointRef | null | undefined;
  review: ReviewRef | null;
  isDone: boolean;
  onDone: () => void;
}) {
  return (
    <StepShell markLabel="R" title="Weak Topic Review" isDone={isDone}>
      {!review ? (
        <div>
          <p className="text-sm text-ink-soft">
            No weak points logged yet — this shows up once you&apos;ve missed a question or two.
          </p>
          <Button variant="paper" className="mt-4 !px-4 !py-2 text-xs" onClick={onDone}>
            Skip for today
          </Button>
        </div>
      ) : (
        <div>
          <p className="font-mono text-xs uppercase tracking-wide text-ink-soft">
            {review.subject} — {review.topic}
            {weakPoint?.subtopic ? ` (${weakPoint.subtopic})` : ""}
          </p>
          <p className="mt-2 text-sm">{review.summary}</p>
          {review.commonMistake && (
            <p className="mt-3 rounded-sm border border-red/30 bg-red/5 px-3 py-2 text-sm">
              <span className="font-mono text-[10px] uppercase tracking-wide text-red">
                Common mistake —{" "}
              </span>
              {review.commonMistake}
            </p>
          )}
          {review.example && (
            <p className="mt-2 rounded-sm border border-green/30 bg-green/5 px-3 py-2 text-sm">
              <span className="font-mono text-[10px] uppercase tracking-wide text-green">
                Example —{" "}
              </span>
              {review.example}
            </p>
          )}
          <Button className="mt-4 !px-4 !py-2 text-xs" onClick={onDone}>
            Got it
          </Button>
        </div>
      )}
    </StepShell>
  );
}

function FlashcardStep({
  flashcard,
  isDone,
  onAnswer,
}: {
  flashcard: FlashcardRef | null;
  isDone: boolean;
  onAnswer: (retained: boolean) => void;
}) {
  const [flipped, setFlipped] = useState(false);

  return (
    <StepShell markLabel="F" title="Flashcard Revision" isDone={isDone}>
      {!flashcard ? (
        <div>
          <p className="text-sm text-ink-soft">No flashcard available today.</p>
          <Button variant="paper" className="mt-4 !px-4 !py-2 text-xs" onClick={() => onAnswer(true)}>
            Mark reviewed
          </Button>
        </div>
      ) : !flipped ? (
        <div>
          <p className="font-mono text-xs uppercase tracking-wide text-ink-soft">
            {flashcard.subject} — {flashcard.topic}
          </p>
          <p className="mt-2 font-display text-xl">{flashcard.front}</p>
          <Button variant="paper" className="mt-4 !px-4 !py-2 text-xs" onClick={() => setFlipped(true)}>
            Flip card
          </Button>
        </div>
      ) : (
        <div>
          <p className="text-sm text-ink-soft">{flashcard.back}</p>
          <p className="mt-3 text-sm text-ink-soft">Did you remember it correctly?</p>
          <div className="mt-2 flex gap-3">
            <Button className="!px-4 !py-2 text-xs" onClick={() => onAnswer(true)}>
              Yes, I remembered
            </Button>
            <Button variant="ghost" className="!px-4 !py-2 text-xs" onClick={() => onAnswer(false)}>
              No, I forgot
            </Button>
          </div>
        </div>
      )}
    </StepShell>
  );
}

function QuizStep({
  title,
  markLabel,
  quiz,
  isDone,
  onAnswer,
}: {
  title: string;
  markLabel: string;
  quiz: QuizRef | null;
  isDone: boolean;
  onAnswer: (isCorrect: boolean) => void;
}) {
  const [selected, setSelected] = useState<number | null>(null);
  const [revealed, setRevealed] = useState(false);

  return (
    <StepShell markLabel={markLabel} title={title} isDone={isDone}>
      {!quiz ? (
        <p className="text-sm text-ink-soft">No question available today.</p>
      ) : (
        <div>
          <p className="font-mono text-xs uppercase tracking-wide text-ink-soft">
            {quiz.subject} — {quiz.topic}
          </p>
          <p className="mt-2">{quiz.question}</p>
          <div className="mt-4 flex flex-col gap-2">
            {quiz.choices.map((choice, i) => {
              const isCorrectChoice = i === quiz.answerIndex;
              const isSelected = i === selected;
              let style = "border-rule hover:border-ink/40";
              if (revealed && isCorrectChoice) style = "border-green bg-green/10";
              else if (revealed && isSelected) style = "border-red bg-red/10";
              return (
                <button
                  key={i}
                  disabled={revealed}
                  onClick={() => setSelected(i)}
                  className={`rounded-sm border px-4 py-2 text-left text-sm transition-colors ${style}`}
                >
                  {choice}
                </button>
              );
            })}
          </div>
          {!revealed ? (
            <Button
              variant="paper"
              className="mt-4 !px-4 !py-2 text-xs"
              disabled={selected === null}
              onClick={() => setRevealed(true)}
            >
              Check answer
            </Button>
          ) : (
            <Button
              className="mt-4 !px-4 !py-2 text-xs"
              onClick={() => onAnswer(selected === quiz.answerIndex)}
            >
              Continue
            </Button>
          )}
        </div>
      )}
    </StepShell>
  );
}
