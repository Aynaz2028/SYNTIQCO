"use client";

import { useState } from "react";
import Link from "next/link";
import { ToggleRow } from "@/components/ToggleRow";
import type { StudentSettings } from "@/lib/settings";

export function NotificationsContent({
  initialSettings,
}: {
  initialSettings: StudentSettings;
}) {
  const [settings, setSettings] = useState<StudentSettings>(initialSettings);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  async function patch(partial: Record<string, boolean>, next: StudentSettings) {
    setSettings(next);
    setSaving(true);
    setSaveError(null);

    const res = await fetch("/api/settings", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(partial),
    });
    setSaving(false);
    if (!res.ok) setSaveError("Couldn't save that change — try again.");
  }

  return (
    <div className="mx-auto max-w-2xl px-6 py-10">
      <Link href="/profile" className="font-mono text-xs uppercase tracking-widest text-amber">
        ← Profile
      </Link>
      <h1 className="mt-3 font-display text-2xl italic">Notifications</h1>
      <p className="mt-2 text-sm text-ink-soft">
        What to send a push notification for. Turn on push from the reminder
        banner on your Dashboard first, or these won&apos;t reach your device.
      </p>

      <section className="paper mt-8 rounded-sm p-6">
        <div className="divide-y divide-rule">
          <ToggleRow
            label="AI Reminder"
            description="A nudge from the AI tutor when a weak topic is due for review before it fades."
            checked={settings.ai_reminder_notifications}
            onChange={(v) =>
              patch(
                { aiReminderNotifications: v },
                { ...settings, ai_reminder_notifications: v }
              )
            }
          />
          <ToggleRow
            label="Daily Mission"
            description="A reminder in the evening if today's mission is still unfinished."
            checked={settings.daily_mission_notifications}
            onChange={(v) =>
              patch(
                { dailyMissionNotifications: v },
                { ...settings, daily_mission_notifications: v }
              )
            }
          />
          <ToggleRow
            label="Friend Activity"
            description="Updates when friends complete missions or pass your streak. Coming with Friends."
            checked={settings.friend_activity_notifications}
            onChange={(v) =>
              patch(
                { friendActivityNotifications: v },
                { ...settings, friend_activity_notifications: v }
              )
            }
          />
        </div>
      </section>

      {(saving || saveError) && (
        <p className={`mt-3 text-xs ${saveError ? "text-red" : "text-paper/50"}`}>
          {saveError ?? "Saving…"}
        </p>
      )}
    </div>
  );
}
