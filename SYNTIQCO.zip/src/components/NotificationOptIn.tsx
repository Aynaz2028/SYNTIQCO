"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/Button";

function urlBase64ToUint8Array(base64String: string) {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const rawData = atob(base64);
  return Uint8Array.from([...rawData].map((char) => char.charCodeAt(0)));
}

export function NotificationOptIn({ vapidPublicKey }: { vapidPublicKey: string | null }) {
  const [status, setStatus] = useState<"idle" | "subscribing" | "on" | "unsupported" | "error">(
    () =>
      typeof window !== "undefined" &&
      ("serviceWorker" in navigator) &&
      ("PushManager" in window)
        ? "idle"
        : "unsupported"
  );

  useEffect(() => {
    if (status === "unsupported") return;
    navigator.serviceWorker.getRegistration().then((reg) => {
      reg?.pushManager.getSubscription().then((sub) => {
        if (sub) setStatus("on");
      });
    });
  }, [status]);

  async function enable() {
    if (!vapidPublicKey) {
      setStatus("error");
      return;
    }
    setStatus("subscribing");
    try {
      const registration = await navigator.serviceWorker.register("/sw.js");
      const permission = await Notification.requestPermission();
      if (permission !== "granted") throw new Error("Permission denied");

      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(vapidPublicKey),
      });

      const json = subscription.toJSON();
      const res = await fetch("/api/push/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ endpoint: json.endpoint, keys: json.keys }),
      });
      if (!res.ok) throw new Error("Failed to save subscription");
      setStatus("on");
    } catch {
      setStatus("error");
    }
  }

  if (status === "unsupported") return null;
  if (status === "on") {
    return <p className="font-mono text-xs text-green">Retention alerts on</p>;
  }

  return (
    <Button
      variant="ghost"
      className="!px-4 !py-2 text-xs"
      disabled={status === "subscribing"}
      onClick={enable}
    >
      {status === "subscribing"
        ? "Enabling…"
        : status === "error"
          ? "Couldn't enable — try again"
          : "Get revision reminders"}
    </Button>
  );
}
