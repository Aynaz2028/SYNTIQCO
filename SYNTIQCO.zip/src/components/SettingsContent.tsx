"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/Button";
import { ToggleRow } from "@/components/ToggleRow";
import {
  LANGUAGE_LABELS,
  THEME_LABELS,
  type Language,
  type StudentSettings,
  type Theme,
} from "@/lib/settings";

function OptionRow<T extends string>({
  options,
  labels,
  value,
  onChange,
}: {
  options: readonly T[];
  labels: Record<T, string>;
  value: T;
  onChange: (v: T) => void;
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {options.map((opt) => (
        <button
          key={opt}
          type="button"
          onClick={() => onChange(opt)}
          className={`rounded-full border px-4 py-2 text-sm transition-colors ${
            value === opt
              ? "border-amber bg-amber/10 text-amber"
              : "border-rule text-ink-soft hover:border-ink/40"
          }`}
        >
          {labels[opt]}
        </button>
      ))}
    </div>
  );
}

export function SettingsContent({ initialSettings }: { initialSettings: StudentSettings }) {
  const router = useRouter();
  const [settings, setSettings] = useState<StudentSettings>(initialSettings);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  const [newPassword, setNewPassword] = useState("");
  const [passwordStatus, setPasswordStatus] = useState<
    { type: "idle" } | { type: "saving" } | { type: "error"; message: string } | { type: "done" }
  >({ type: "idle" });

  const [signingOutEverywhere, setSigningOutEverywhere] = useState(false);

  async function patch(partial: Record<string, string | boolean>, next: StudentSettings) {
    setSettings(next);
    setSaving(true);
    setSaveError(null);

    // Instant, no-flicker theme switch — don't wait on the network for this.
    if ("theme" in partial && typeof partial.theme === "string") {
      if (partial.theme === "system") {
        document.documentElement.removeAttribute("data-theme");
      } else {
        document.documentElement.setAttribute("data-theme", partial.theme);
      }
    }

    const res = await fetch("/api/settings", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(partial),
    });
    setSaving(false);
    if (!res.ok) setSaveError("Couldn't save that change — try again.");
  }

  async function changePassword(e: React.FormEvent) {
    e.preventDefault();
    if (newPassword.length < 6) {
      setPasswordStatus({ type: "error", message: "Password must be at least 6 characters." });
      return;
    }
    setPasswordStatus({ type: "saving" });
    const supabase = createClient();
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    if (error) {
      setPasswordStatus({ type: "error", message: error.message });
      return;
    }
    setNewPassword("");
    setPasswordStatus({ type: "done" });
  }

  async function signOutEverywhere() {
    setSigningOutEverywhere(true);
    const supabase = createClient();
    await supabase.auth.signOut({ scope: "global" });
    router.replace("/login");
    router.refresh();
  }

  return (
    <div className="mx-auto max-w-2xl px-6 py-10">
      <Link href="/profile" className="font-mono text-xs uppercase tracking-widest text-amber">
        ← Profile
      </Link>
      <h1 className="mt-3 font-display text-2xl italic">Settings</h1>

      {/* Appearance */}
      <section className="paper mt-8 rounded-sm p-6">
        <h2 className="font-mono text-xs uppercase tracking-wide text-ink-soft">Appearance</h2>
        <p className="mt-3 text-sm text-ink-soft">Theme</p>
        <div className="mt-2">
          <OptionRow<Theme>
            options={["dark", "light", "system"]}
            labels={THEME_LABELS}
            value={settings.theme}
            onChange={(theme) => patch({ theme }, { ...settings, theme })}
          />
        </div>
        <p className="mt-5 text-sm text-ink-soft">Language</p>
        <div className="mt-2">
          <OptionRow<Language>
            options={["en", "bn"]}
            labels={LANGUAGE_LABELS}
            value={settings.language}
            onChange={(language) => patch({ language }, { ...settings, language })}
          />
        </div>
      </section>

      {/* Privacy */}
      <section className="paper mt-6 rounded-sm p-6">
        <h2 className="font-mono text-xs uppercase tracking-wide text-ink-soft">Privacy</h2>
        <div className="mt-2 divide-y divide-rule">
          <ToggleRow
            label="Show on leaderboard"
            description="Let other students see your streak and rank."
            checked={settings.show_on_leaderboard}
            onChange={(v) =>
              patch(
                { showOnLeaderboard: v },
                { ...settings, show_on_leaderboard: v }
              )
            }
          />
          <ToggleRow
            label="Share progress with friends"
            description="Friends you follow can see your subject mastery."
            checked={settings.share_progress_with_friends}
            onChange={(v) =>
              patch(
                { shareProgressWithFriends: v },
                { ...settings, share_progress_with_friends: v }
              )
            }
          />
        </div>
      </section>

      {(saving || saveError) && (
        <p className={`mt-3 text-xs ${saveError ? "text-red" : "text-paper/50"}`}>
          {saveError ?? "Saving…"}
        </p>
      )}

      {/* Security */}
      <section className="paper mt-6 rounded-sm p-6">
        <h2 className="font-mono text-xs uppercase tracking-wide text-ink-soft">Security</h2>

        <form onSubmit={changePassword} className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-end">
          <label className="flex-1 text-sm text-ink">
            New password
            <input
              type="password"
              minLength={6}
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="At least 6 characters"
              className="mt-1 w-full rounded-sm border border-rule bg-transparent px-3 py-2 text-ink outline-none focus:border-amber"
            />
          </label>
          <Button
            type="submit"
            variant="paper"
            disabled={passwordStatus.type === "saving" || newPassword.length === 0}
          >
            {passwordStatus.type === "saving" ? "Updating…" : "Update password"}
          </Button>
        </form>
        {passwordStatus.type === "error" && (
          <p className="mt-2 text-sm text-red">{passwordStatus.message}</p>
        )}
        {passwordStatus.type === "done" && (
          <p className="mt-2 text-sm text-green">Password updated.</p>
        )}

        <div className="mt-6 flex items-center justify-between gap-4 border-t border-rule pt-4">
          <div>
            <p className="text-sm text-ink">Sign out of all devices</p>
            <p className="mt-0.5 text-xs text-ink-soft">
              Ends every active session, including this one.
            </p>
          </div>
          <Button variant="ghost" onClick={signOutEverywhere} disabled={signingOutEverywhere}>
            {signingOutEverywhere ? "Signing out…" : "Sign out everywhere"}
          </Button>
        </div>
      </section>
    </div>
  );
}
