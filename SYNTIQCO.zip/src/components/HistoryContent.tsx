"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { MarginMark } from "@/components/MarginMark";

interface WeakPoint {
  id: string;
  subject: string;
  topic: string;
  subtopic: string | null;
  error_type: string;
  decay_score: number;
  times_reviewed: number;
  created_at: string;
}

const ERROR_LABELS: Record<string, string> = {
  wrong_answer: "Wrong answer",
  skipped_step: "Skipped step",
  conceptual_gap: "Conceptual gap",
};

export function HistoryContent() {
  const [weakPoints, setWeakPoints] = useState<WeakPoint[] | null>(null);
  const [tier, setTier] = useState<string | null>(null);
  const [historyLimitDays, setHistoryLimitDays] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/weak-points")
      .then(async (res) => {
        if (!res.ok) throw new Error((await res.json()).error ?? "Failed to load");
        return res.json();
      })
      .then((data) => {
        setWeakPoints(data.weakPoints);
        setTier(data.tier);
        setHistoryLimitDays(data.historyLimitDays);
      })
      .catch((err) => setError(err.message));
  }, []);

  return (
    <div className="mx-auto max-w-2xl px-6 py-10">
      <p className="font-mono text-xs uppercase tracking-widest text-amber">Memory</p>
      <h1 className="mt-1 font-display text-2xl italic">Every weak point, remembered</h1>
      <p className="mt-2 text-sm text-paper/60">
        Everything the AI Solver, quizzes, and past-paper MCQs have caught — ranked by how due
        each one is for revision.
      </p>

      {tier === "free" && historyLimitDays && (
        <div className="mt-6 rounded-sm border border-amber/40 bg-amber/10 px-5 py-3 text-sm">
          Free tier shows your last {historyLimitDays} days of memory history.{" "}
          <Link href="/subscription" className="text-amber underline">
            Upgrade to Pro
          </Link>{" "}
          for your full history.
        </div>
      )}

      {error && <p className="mt-6 text-sm text-red">{error}</p>}

      {weakPoints === null && !error && (
        <p className="mt-6 text-sm text-paper/60">Loading your memory engine…</p>
      )}

      {weakPoints && weakPoints.length === 0 && (
        <div className="paper mt-6 rounded-sm p-6 text-center text-sm text-ink-soft">
          Nothing logged yet — mistakes you make in the AI Solver, daily quiz, or past-paper MCQ
          will show up here.
        </div>
      )}

      <div className="mt-6 space-y-3">
        {weakPoints?.map((wp) => {
          const duePct = Math.round(wp.decay_score * 100);
          return (
            <div key={wp.id} className="paper rounded-sm p-5">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="font-mono text-xs uppercase tracking-wide text-ink-soft">
                    {wp.subject} — {wp.topic}
                    {wp.subtopic ? ` (${wp.subtopic})` : ""}
                  </p>
                  <p className="mt-1 font-display text-lg">
                    {ERROR_LABELS[wp.error_type] ?? wp.error_type}
                  </p>
                  <p className="mt-1 text-xs text-ink-soft">
                    Logged {new Date(wp.created_at).toLocaleDateString()} · reviewed{" "}
                    {wp.times_reviewed}x
                  </p>
                </div>
                <MarginMark
                  label={duePct >= 50 ? "due" : "ok"}
                  variant={duePct >= 50 ? "red" : "green"}
                />
              </div>
              <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-ink/10">
                <div
                  className={duePct >= 50 ? "h-full bg-red" : "h-full bg-green"}
                  style={{ width: `${duePct}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
