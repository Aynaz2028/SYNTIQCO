const MILESTONE_LABELS: Record<string, string> = {
  "7_day": "7-day",
  "14_day": "14-day",
  "30_day": "30-day",
};

export function StreakBadge({
  currentStreak,
  badges,
}: {
  currentStreak: number;
  badges: string[];
}) {
  return (
    <div className="paper-dark flex items-center gap-4 rounded-sm px-5 py-4">
      <div>
        <p className="font-display text-3xl">{currentStreak}</p>
        <p className="font-mono text-[10px] uppercase tracking-wide text-paper/60">
          day streak
        </p>
      </div>
      {badges.length > 0 && (
        <div className="flex gap-2 border-l border-rule-dark pl-4">
          {badges.map((b) => (
            <span
              key={b}
              className="rounded-full border border-amber px-2 py-1 font-mono text-[10px] text-amber"
            >
              {MILESTONE_LABELS[b] ?? b}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
