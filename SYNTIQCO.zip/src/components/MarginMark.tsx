export function MarginMark({
  label,
  variant = "red",
}: {
  label: string;
  variant?: "red" | "green";
}) {
  return <span className={`mark ${variant === "green" ? "mark-green" : ""}`}>{label}</span>;
}
