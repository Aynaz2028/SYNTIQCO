"use client";

import { useEffect, useId, useRef, useState } from "react";
import type { Emotion } from "@/lib/emotion";

export type AvatarState = "idle" | "listening" | "thinking" | "speaking";

const EMOTION_COLOR: Record<Emotion, string> = {
  neutral: "var(--accent-amber)",
  happy: "var(--accent-green)",
  encouraging: "var(--accent-green)",
  celebrating: "var(--accent-amber)",
  thinking: "var(--accent-amber)",
  curious: "var(--accent-amber)",
};

/** Eyebrow paths per emotion, drawn relative to a 200x200 viewBox face centered at (100,88). */
const BROWS: Record<Emotion, { left: string; right: string }> = {
  neutral: { left: "M70,72 Q82,68 94,72", right: "M106,72 Q118,68 130,72" },
  happy: { left: "M70,74 Q82,64 94,70", right: "M106,70 Q118,64 130,74" },
  encouraging: { left: "M70,73 Q82,66 94,71", right: "M106,71 Q118,66 130,73" },
  celebrating: { left: "M68,70 Q82,58 96,68", right: "M104,68 Q118,58 132,70" },
  thinking: { left: "M70,70 Q82,74 94,72", right: "M106,64 Q118,58 130,66" },
  curious: { left: "M70,68 Q82,62 94,70", right: "M106,68 Q118,62 130,70" },
};

/** Resting mouth shape per emotion (used whenever the avatar isn't actively "talking"). */
const MOUTH_REST: Record<Emotion, string> = {
  neutral: "M78,124 Q100,130 122,124",
  happy: "M76,120 Q100,140 124,120",
  encouraging: "M78,122 Q100,134 122,122",
  celebrating: "M74,118 Q100,144 126,118",
  thinking: "M82,126 Q100,124 118,126",
  curious: "M84,124 Q100,120 116,128",
};

/** Open-mouth frames cycled through while speaking, to fake lip-sync without real audio analysis. */
const TALK_FRAMES = [
  "M80,122 Q100,126 120,122",
  "M82,118 Q100,142 118,118",
  "M84,120 Q100,132 116,120",
  "M80,116 Q100,146 120,116",
];

export function TutorAvatar({
  state,
  emotion,
  emoji,
  size = "md",
}: {
  state: AvatarState;
  emotion: Emotion;
  emoji?: string;
  size?: "sm" | "md" | "lg";
}) {
  const uid = useId();
  const [blink, setBlink] = useState(false);
  const [talkFrame, setTalkFrame] = useState(0);
  const talkIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Idle blinking, independent of state, so the avatar never looks frozen.
  useEffect(() => {
    let cancelled = false;
    let timeout: ReturnType<typeof setTimeout>;
    const scheduleBlink = () => {
      const delay = 2200 + Math.random() * 2800;
      timeout = setTimeout(() => {
        if (cancelled) return;
        setBlink(true);
        setTimeout(() => !cancelled && setBlink(false), 130);
        scheduleBlink();
      }, delay);
    };
    scheduleBlink();
    return () => {
      cancelled = true;
      clearTimeout(timeout);
    };
  }, []);

  // Mouth movement while "speaking" — cycles through open-shape frames at an
  // irregular-ish cadence so it reads as talking rather than a metronome.
  useEffect(() => {
    if (state !== "speaking") {
      if (talkIntervalRef.current) clearInterval(talkIntervalRef.current);
      return;
    }
    talkIntervalRef.current = setInterval(
      () => setTalkFrame((f) => (f + 1) % TALK_FRAMES.length),
      110
    );
    return () => {
      if (talkIntervalRef.current) clearInterval(talkIntervalRef.current);
      setTalkFrame(0);
    };
  }, [state]);

  const dims = size === "lg" ? 160 : size === "sm" ? 40 : 64;
  const accent = EMOTION_COLOR[emotion];
  const mouthPath = state === "speaking" ? TALK_FRAMES[talkFrame] : MOUTH_REST[emotion];
  const brows = BROWS[emotion];
  const eyeScaleY = blink ? 0.08 : state === "thinking" ? 0.85 : 1;

  return (
    <div
      className="relative inline-flex shrink-0 items-center justify-center"
      style={{ width: dims, height: dims }}
      role="img"
      aria-label={`Tutor avatar, ${state}, feeling ${emotion}`}
    >
      {/* Listening pulse ring */}
      {state === "listening" && (
        <span
          className="absolute inset-0 animate-ping rounded-full opacity-40"
          style={{ background: accent }}
        />
      )}
      {/* Thinking dots */}
      {state === "thinking" && (
        <span className="absolute -top-1 left-1/2 flex -translate-x-1/2 gap-0.5">
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className="h-1 w-1 animate-bounce rounded-full"
              style={{ background: accent, animationDelay: `${i * 120}ms` }}
            />
          ))}
        </span>
      )}
      <svg
        viewBox="0 0 200 200"
        width={dims}
        height={dims}
        className="relative transition-transform duration-300"
        style={{ transform: state === "speaking" ? "scale(1.03)" : "scale(1)" }}
      >
        <defs>
          <clipPath id={`${uid}-clip`}>
            <circle cx="100" cy="100" r="94" />
          </clipPath>
        </defs>

        <circle
          cx="100"
          cy="100"
          r="94"
          fill="var(--bg-paper)"
          stroke={accent}
          strokeWidth={state === "listening" ? 4 : 2.5}
          className="transition-all duration-300"
        />

        <g clipPath={`url(#${uid}-clip)`}>
          {/* Eyes */}
          <g style={{ transformOrigin: "77px 96px", transform: `scaleY(${eyeScaleY})` }}>
            <ellipse cx="77" cy="96" rx="7" ry="9" fill="var(--ink)" />
          </g>
          <g style={{ transformOrigin: "123px 96px", transform: `scaleY(${eyeScaleY})` }}>
            <ellipse cx="123" cy="96" rx="7" ry="9" fill="var(--ink)" />
          </g>

          {/* Eyebrows */}
          <path d={brows.left} stroke="var(--ink)" strokeWidth="4" strokeLinecap="round" fill="none" />
          <path d={brows.right} stroke="var(--ink)" strokeWidth="4" strokeLinecap="round" fill="none" />

          {/* Cheeks — only visible for warmer emotions */}
          {(emotion === "happy" || emotion === "celebrating" || emotion === "encouraging") && (
            <>
              <circle cx="62" cy="118" r="8" fill={accent} opacity="0.25" />
              <circle cx="138" cy="118" r="8" fill={accent} opacity="0.25" />
            </>
          )}

          {/* Mouth */}
          <path
            d={mouthPath}
            stroke="var(--ink)"
            strokeWidth="4"
            strokeLinecap="round"
            fill={state === "speaking" ? "var(--ink)" : "none"}
            fillOpacity={state === "speaking" ? 0.12 : 1}
            className="transition-all duration-75"
          />
        </g>
      </svg>

      {emoji && (
        <span
          className="absolute -bottom-1 -right-1 flex items-center justify-center rounded-full border border-rule-dark bg-bg-ink text-[11px] leading-none"
          style={{ width: dims * 0.32, height: dims * 0.32, fontSize: dims * 0.16 }}
        >
          {emoji}
        </span>
      )}
    </div>
  );
}
