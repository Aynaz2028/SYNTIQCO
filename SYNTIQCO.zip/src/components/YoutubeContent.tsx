"use client";

import { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/Button";
import { MarginMark } from "@/components/MarginMark";

interface QuizQuestion {
  question: string;
  choices: string[];
  answerIndex: number;
}

interface VideoLesson {
  id: string;
  videoId: string;
  videoUrl: string;
  title: string;
  thumbnailUrl: string;
  subject: string;
  summary: string;
  keyPoints: string[];
  quiz: QuizQuestion[];
  quizResults: Record<string, boolean>;
}

interface UsageInfo {
  used: number;
  limit: number;
}

export function YoutubeContent({ subjects, tier }: { subjects: string[]; tier: string }) {
  const [url, setUrl] = useState("");
  const [subject, setSubject] = useState(subjects[0] ?? "General");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [usage, setUsage] = useState<UsageInfo | null>(null);
  const [lesson, setLesson] = useState<VideoLesson | null>(null);

  const limitReached = usage !== null && usage.used >= usage.limit;

  async function analyzeVideo(e: React.FormEvent) {
    e.preventDefault();
    if (!url.trim()) return;

    setLoading(true);
    setError(null);
    setLesson(null);

    try {
      const res = await fetch("/api/youtube/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: url.trim(), subject }),
      });
      const data = await res.json();

      if (res.status === 429) {
        setUsage({ used: data.used, limit: data.limit });
        setError("Daily free-tier YouTube Learning limit reached.");
        return;
      }
      if (!res.ok) {
        setError(typeof data.error === "string" ? data.error : "Something went wrong.");
        return;
      }

      setLesson(data.lesson);
      setUsage(data.usage ? { used: data.usage.used, limit: data.usage.limit } : null);
    } catch {
      setError("Network error — check your connection and try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-2xl px-6 py-10">
      <p className="font-mono text-xs uppercase tracking-widest text-amber">YouTube Learning</p>
      <h1 className="mt-1 font-display text-2xl italic">
        Paste a link, get a summary and a quiz
      </h1>
      <p className="mt-2 text-sm text-paper/60">
        Drop in any educational YouTube video. HabitFirst reads its captions, summarizes what it
        teaches, and builds a short quiz to check you actually understood it.
      </p>

      <form onSubmit={analyzeVideo} className="paper mt-8 rounded-sm p-6">
        <label className="text-sm text-ink">
          YouTube link
          <input
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="https://www.youtube.com/watch?v=…"
            className="mt-1 w-full rounded-sm border border-rule bg-transparent px-3 py-2 text-ink outline-none focus:border-ink/40"
          />
        </label>

        <div className="mt-4 flex flex-wrap items-center gap-4">
          <select
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            className="rounded-sm border border-rule bg-transparent px-3 py-1.5 text-sm text-ink outline-none focus:border-ink/40"
          >
            {(subjects.length > 0 ? subjects : ["General"]).map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>

        {error && <p className="mt-4 text-sm text-red">{error}</p>}
        {usage && (
          <p className="mt-2 font-mono text-xs text-ink-soft">
            {usage.used}/{usage.limit === Infinity ? "∞" : usage.limit} videos analyzed today
            {limitReached && tier === "free" && (
              <>
                {" — "}
                <Link href="/subscription" className="text-red underline">
                  upgrade to Pro
                </Link>
              </>
            )}
          </p>
        )}

        <Button type="submit" className="mt-5" disabled={loading || !url.trim()}>
          {loading ? "Reading & summarizing…" : "Analyze video"}
        </Button>
      </form>

      {lesson && (
        <div className="paper mt-6 rounded-sm p-6">
          <div className="flex gap-4">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={lesson.thumbnailUrl}
              alt={lesson.title}
              className="h-20 w-32 flex-shrink-0 rounded-sm border border-rule object-cover"
            />
            <div>
              <p className="font-mono text-xs uppercase tracking-wide text-ink-soft">
                {lesson.subject}
              </p>
              <a
                href={lesson.videoUrl}
                target="_blank"
                rel="noreferrer"
                className="font-display text-lg underline decoration-rule underline-offset-2 hover:decoration-ink"
              >
                {lesson.title}
              </a>
            </div>
          </div>

          <div className="mt-5 border-t border-rule pt-4">
            <p className="font-mono text-[10px] uppercase tracking-wide text-amber">Summary</p>
            <p className="mt-2 text-sm">{lesson.summary}</p>
            {lesson.keyPoints.length > 0 && (
              <ul className="mt-3 list-inside list-disc space-y-1 text-sm text-ink-soft">
                {lesson.keyPoints.map((point, i) => (
                  <li key={i}>{point}</li>
                ))}
              </ul>
            )}
          </div>

          {lesson.quiz.length > 0 && (
            <div className="mt-6 border-t border-rule pt-4">
              <p className="font-mono text-[10px] uppercase tracking-wide text-amber">
                Quiz — check your understanding
              </p>
              <div className="mt-3 space-y-4">
                {lesson.quiz.map((q, i) => (
                  <VideoQuizQuestionCard
                    key={i}
                    index={i}
                    quiz={q}
                    lessonId={lesson.id}
                    subject={lesson.subject}
                    topic={lesson.title}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function VideoQuizQuestionCard({
  index,
  quiz,
  lessonId,
  subject,
  topic,
}: {
  index: number;
  quiz: QuizQuestion;
  lessonId: string;
  subject: string;
  topic: string;
}) {
  const [selected, setSelected] = useState<number | null>(null);
  const [revealed, setRevealed] = useState(false);
  const isCorrect = selected === quiz.answerIndex;

  async function checkAnswer() {
    if (selected === null) return;
    setRevealed(true);
    try {
      await fetch("/api/youtube/quiz-answer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          lessonId,
          questionIndex: index,
          question: quiz.question,
          subject,
          topic,
          isCorrect,
        }),
      });
    } catch {
      // Logging the attempt is best-effort — the reveal the student
      // already sees doesn't depend on it.
    }
  }

  return (
    <div className="rounded-sm border border-rule p-4">
      <p className="text-sm">
        {index + 1}. {quiz.question}
      </p>
      <div className="mt-3 flex flex-col gap-2">
        {quiz.choices.map((choice, i) => {
          const isCorrectChoice = i === quiz.answerIndex;
          const isSelected = i === selected;
          let style = "border-rule hover:border-ink/40";
          if (revealed && isCorrectChoice) style = "border-green bg-green/10";
          else if (revealed && isSelected) style = "border-red bg-red/10";
          return (
            <button
              key={i}
              type="button"
              disabled={revealed}
              onClick={() => setSelected(i)}
              className={`rounded-sm border px-3 py-1.5 text-left text-sm transition-colors ${style}`}
            >
              {choice}
            </button>
          );
        })}
      </div>
      {!revealed ? (
        <Button
          variant="paper"
          className="mt-3 !px-4 !py-2 text-xs"
          disabled={selected === null}
          onClick={checkAnswer}
        >
          Check answer
        </Button>
      ) : (
        <div className="mt-3 flex items-center gap-2">
          <MarginMark label={isCorrect ? "✓" : "✕"} variant={isCorrect ? "green" : "red"} />
          <span className="text-xs text-ink-soft">
            {isCorrect ? "Correct." : "Not quite — correct choice highlighted."}
          </span>
        </div>
      )}
    </div>
  );
}
