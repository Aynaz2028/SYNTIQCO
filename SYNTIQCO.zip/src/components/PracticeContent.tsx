"use client";

import { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/Button";
import { MarginMark } from "@/components/MarginMark";

type Mode = "mcq" | "written";

interface McqItem {
  mode: "mcq";
  subject: string;
  topic: string;
  subtopic: string | null;
  question: string;
  choices: string[];
  answerIndex: number;
}

interface WrittenItem {
  mode: "written";
  subject: string;
  topic: string;
  subtopic: string | null;
  question: string;
  maxMarks: number;
  modelAnswer: string;
}

type PracticeItem = McqItem | WrittenItem;

interface WrittenGrade {
  marksAwarded: number;
  maxMarks: number;
  isCorrect: boolean;
  feedback: string;
  modelAnswer: string;
}

interface UsageInfo {
  used: number;
  limit: number;
}

export function PracticeContent({
  subjects,
  tier,
}: {
  subjects: string[];
  tier: string;
}) {
  const [subject, setSubject] = useState(subjects[0] ?? "General");
  const [topic, setTopic] = useState("");
  const [mode, setMode] = useState<Mode>("mcq");

  const [item, setItem] = useState<PracticeItem | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [usage, setUsage] = useState<UsageInfo | null>(null);

  // MCQ state
  const [selected, setSelected] = useState<number | null>(null);
  const [revealed, setRevealed] = useState(false);

  // Written state
  const [studentAnswer, setStudentAnswer] = useState("");
  const [grading, setGrading] = useState(false);
  const [grade, setGrade] = useState<WrittenGrade | null>(null);

  const limitReached = usage !== null && usage.used >= usage.limit;

  function resetAttemptState() {
    setSelected(null);
    setRevealed(false);
    setStudentAnswer("");
    setGrade(null);
  }

  async function generateQuestion(e?: React.FormEvent) {
    e?.preventDefault();
    if (!topic.trim()) {
      setError("Give it a topic to practice — e.g. \"Newton's laws\" or \"Cell division\".");
      return;
    }

    setLoading(true);
    setError(null);
    resetAttemptState();

    try {
      const res = await fetch("/api/practice/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ subject, topic: topic.trim(), mode }),
      });
      const data = await res.json();

      if (res.status === 429) {
        setUsage({ used: data.used, limit: data.limit });
        setError("Daily free-tier Practice limit reached.");
        setItem(null);
        return;
      }
      if (!res.ok) {
        setError(typeof data.error === "string" ? data.error : "Something went wrong.");
        return;
      }

      setItem(data.item);
      setUsage(data.usage ? { used: data.usage.used, limit: data.usage.limit } : null);
    } catch {
      setError("Network error — check your connection and try again.");
    } finally {
      setLoading(false);
    }
  }

  async function checkMcqAnswer() {
    if (!item || item.mode !== "mcq" || selected === null) return;
    setRevealed(true);
    try {
      await fetch("/api/practice/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: "mcq",
          subject: item.subject,
          topic: item.topic,
          subtopic: item.subtopic,
          question: item.question,
          answerIndex: item.answerIndex,
          selectedIndex: selected,
        }),
      });
    } catch {
      // Logging the attempt is best-effort — the feedback the student
      // already sees (revealed choices) doesn't depend on it.
    }
  }

  async function submitWrittenAnswer() {
    if (!item || item.mode !== "written") return;
    setGrading(true);
    setError(null);
    try {
      const res = await fetch("/api/practice/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: "written",
          subject: item.subject,
          topic: item.topic,
          subtopic: item.subtopic,
          question: item.question,
          maxMarks: item.maxMarks,
          modelAnswer: item.modelAnswer,
          studentAnswer,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(typeof data.error === "string" ? data.error : "Could not grade this answer.");
        return;
      }
      setGrade(data);
    } catch {
      setError("Network error — check your connection and try again.");
    } finally {
      setGrading(false);
    }
  }

  return (
    <div className="mx-auto max-w-2xl px-6 py-10">
      <p className="font-mono text-xs uppercase tracking-widest text-amber">Practice</p>
      <h1 className="mt-1 font-display text-2xl italic">
        Pick a topic, pick a mode, get instant AI feedback
      </h1>
      <p className="mt-2 text-sm text-paper/60">
        Unlike the daily mission, you choose exactly what to drill. MCQ for a quick check, Written
        Answer for exam-style marking.
      </p>

      <div className="paper mt-8 rounded-sm p-6">
        <div className="flex gap-2">
          {(["mcq", "written"] as Mode[]).map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => {
                setMode(m);
                setItem(null);
                resetAttemptState();
                setError(null);
              }}
              className={`rounded-full px-4 py-1.5 font-mono text-xs uppercase tracking-wide transition-colors ${
                mode === m
                  ? "bg-ink text-paper"
                  : "border border-rule text-ink-soft hover:border-ink/40"
              }`}
            >
              {m === "mcq" ? "MCQ" : "Written Answer"}
            </button>
          ))}
        </div>

        <form onSubmit={generateQuestion} className="mt-5 flex flex-col gap-3 sm:flex-row">
          <select
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            className="rounded-sm border border-rule bg-transparent px-3 py-2 text-sm text-ink outline-none focus:border-ink/40"
          >
            {(subjects.length > 0 ? subjects : ["General"]).map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
          <input
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="Topic — e.g. Newton's laws"
            className="flex-1 rounded-sm border border-rule bg-transparent px-3 py-2 text-sm text-ink outline-none focus:border-ink/40"
          />
          <Button type="submit" disabled={loading || limitReached} className="!px-5 !py-2 text-xs">
            {loading ? "Generating…" : "New question"}
          </Button>
        </form>

        {error && <p className="mt-4 text-sm text-red">{error}</p>}
        {usage && (
          <p className="mt-2 font-mono text-xs text-ink-soft">
            {usage.used}/{usage.limit === Infinity ? "∞" : usage.limit} practice questions used
            today
            {limitReached && tier === "free" && (
              <>
                {" — "}
                <Link href="/subscription" className="text-red underline">
                  upgrade to Pro
                </Link>
              </>
            )}
          </p>
        )}
      </div>

      {item && item.mode === "mcq" && (
        <McqPracticeCard
          item={item}
          selected={selected}
          revealed={revealed}
          onSelect={setSelected}
          onCheck={checkMcqAnswer}
        />
      )}

      {item && item.mode === "written" && (
        <WrittenPracticeCard
          item={item}
          studentAnswer={studentAnswer}
          onChangeAnswer={setStudentAnswer}
          grading={grading}
          grade={grade}
          onSubmit={submitWrittenAnswer}
        />
      )}
    </div>
  );
}

function McqPracticeCard({
  item,
  selected,
  revealed,
  onSelect,
  onCheck,
}: {
  item: McqItem;
  selected: number | null;
  revealed: boolean;
  onSelect: (i: number) => void;
  onCheck: () => void;
}) {
  const isCorrect = selected === item.answerIndex;

  return (
    <div className="paper mt-6 rounded-sm p-6">
      <p className="font-mono text-xs uppercase tracking-wide text-ink-soft">
        {item.subject} — {item.topic}
      </p>
      <p className="mt-2">{item.question}</p>
      <div className="mt-4 flex flex-col gap-2">
        {item.choices.map((choice, i) => {
          const isCorrectChoice = i === item.answerIndex;
          const isSelected = i === selected;
          let style = "border-rule hover:border-ink/40";
          if (revealed && isCorrectChoice) style = "border-green bg-green/10";
          else if (revealed && isSelected) style = "border-red bg-red/10";
          return (
            <button
              key={i}
              type="button"
              disabled={revealed}
              onClick={() => onSelect(i)}
              className={`rounded-sm border px-4 py-2 text-left text-sm transition-colors ${style}`}
            >
              {choice}
            </button>
          );
        })}
      </div>

      {!revealed ? (
        <Button
          variant="paper"
          className="mt-4 !px-4 !py-2 text-xs"
          disabled={selected === null}
          onClick={onCheck}
        >
          Check answer
        </Button>
      ) : (
        <div className="mt-4 flex items-center gap-3">
          <MarginMark label={isCorrect ? "✓" : "✕"} variant={isCorrect ? "green" : "red"} />
          <span className="text-sm">
            {isCorrect ? "Correct." : "Not quite — the correct choice is highlighted."}
          </span>
        </div>
      )}
    </div>
  );
}

function WrittenPracticeCard({
  item,
  studentAnswer,
  onChangeAnswer,
  grading,
  grade,
  onSubmit,
}: {
  item: WrittenItem;
  studentAnswer: string;
  onChangeAnswer: (v: string) => void;
  grading: boolean;
  grade: WrittenGrade | null;
  onSubmit: () => void;
}) {
  return (
    <div className="paper mt-6 rounded-sm p-6">
      <p className="font-mono text-xs uppercase tracking-wide text-ink-soft">
        {item.subject} — {item.topic} · {item.maxMarks} mark{item.maxMarks === 1 ? "" : "s"}
      </p>
      <p className="mt-2">{item.question}</p>

      <textarea
        value={studentAnswer}
        onChange={(e) => onChangeAnswer(e.target.value)}
        disabled={Boolean(grade)}
        rows={5}
        placeholder="Write your answer — full sentences, show your working where relevant."
        className="mt-4 w-full rounded-sm border border-rule bg-transparent px-3 py-2 text-sm text-ink outline-none focus:border-ink/40 disabled:opacity-70"
      />

      {!grade ? (
        <Button
          variant="paper"
          className="mt-4 !px-4 !py-2 text-xs"
          disabled={grading || !studentAnswer.trim()}
          onClick={onSubmit}
        >
          {grading ? "Marking…" : "Submit for AI feedback"}
        </Button>
      ) : (
        <div className="mt-4 space-y-3 border-t border-rule pt-4">
          <div className="flex items-center gap-3">
            <MarginMark
              label={`${grade.marksAwarded}/${grade.maxMarks}`}
              variant={grade.isCorrect ? "green" : "red"}
            />
            <span className="font-mono text-xs uppercase tracking-wide text-ink-soft">
              Instant AI feedback
            </span>
          </div>
          <p className="text-sm">{grade.feedback}</p>
          <p className="rounded-sm border border-green/30 bg-green/5 px-3 py-2 text-sm">
            <span className="font-mono text-[10px] uppercase tracking-wide text-green">
              Model answer —{" "}
            </span>
            {grade.modelAnswer}
          </p>
        </div>
      )}
    </div>
  );
}
