"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/Button";
import {
  AVATARS,
  PERSONALITIES,
  VOICES,
  type Personality,
  type Voice,
} from "@/lib/tutor";
import type { Language } from "@/lib/settings";

const STEP_COUNT = 6;

export function TutorCreationContent({ subjects }: { subjects: string[] }) {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  const [subject, setSubject] = useState<string | null>(null);
  const [personality, setPersonality] = useState<Personality | null>(null);
  const [voice, setVoice] = useState<Voice | null>(null);
  const [avatar, setAvatar] = useState<string | null>(null);
  const [language, setLanguage] = useState<Language | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const availableSubjects = [...subjects, "General"];

  async function finish() {
    if (!name.trim() || !subject || !personality || !voice || !avatar || !language) return;
    setSubmitting(true);
    setError(null);
    const res = await fetch("/api/tutor", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: name.trim(), subject, personality, voice, avatar, language }),
    });
    const data = await res.json();
    setSubmitting(false);
    if (!res.ok) {
      setError(typeof data.error === "string" ? data.error : "Something went wrong. Try again.");
      return;
    }
    router.replace(`/chat/${data.tutor.id}`);
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-xl flex-col justify-center px-6 py-16">
      <p className="font-mono text-xs uppercase tracking-widest text-amber">
        Step {step + 1} of {STEP_COUNT}
      </p>

      {step === 0 && (
        <div className="mt-4">
          <h1 className="font-display text-2xl">What should your tutor be called?</h1>
          <input
            autoFocus
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Prof. Rahman"
            maxLength={40}
            className="mt-6 w-full rounded-sm border border-rule-dark bg-transparent px-3 py-2 outline-none focus:border-amber"
          />
          <Button className="mt-8" disabled={!name.trim()} onClick={() => setStep(1)}>
            Continue
          </Button>
        </div>
      )}

      {step === 1 && (
        <div className="mt-4">
          <h1 className="font-display text-2xl">Which subject?</h1>
          <div className="mt-6 flex flex-wrap gap-3">
            {availableSubjects.map((s) => (
              <button
                key={s}
                onClick={() => setSubject(s)}
                className={`rounded-full border px-4 py-2 text-sm transition-colors ${
                  subject === s
                    ? "border-amber bg-amber/10 text-amber"
                    : "border-rule-dark hover:border-paper/40"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
          <div className="mt-8 flex gap-3">
            <Button variant="ghost" onClick={() => setStep(0)}>
              Back
            </Button>
            <Button disabled={!subject} onClick={() => setStep(2)}>
              Continue
            </Button>
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="mt-4">
          <h1 className="font-display text-2xl">Pick a personality</h1>
          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            {PERSONALITIES.map((p) => (
              <button
                key={p.value}
                onClick={() => setPersonality(p.value)}
                className={`rounded-sm border p-5 text-left transition-colors ${
                  personality === p.value
                    ? "border-amber bg-amber/10"
                    : "border-rule-dark hover:border-paper/40"
                }`}
              >
                <p className="font-display text-lg">{p.label}</p>
                <p className="mt-1 text-xs text-paper/60">{p.blurb}</p>
              </button>
            ))}
          </div>
          <div className="mt-8 flex gap-3">
            <Button variant="ghost" onClick={() => setStep(1)}>
              Back
            </Button>
            <Button disabled={!personality} onClick={() => setStep(3)}>
              Continue
            </Button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="mt-4">
          <h1 className="font-display text-2xl">Choose a voice</h1>
          <p className="mt-2 text-sm text-paper/60">
            Used when your tutor reads replies aloud in chat.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            {VOICES.map((v) => (
              <button
                key={v.value}
                onClick={() => setVoice(v.value)}
                className={`rounded-full border px-5 py-2 text-sm transition-colors ${
                  voice === v.value
                    ? "border-amber bg-amber/10 text-amber"
                    : "border-rule-dark hover:border-paper/40"
                }`}
              >
                {v.label}
              </button>
            ))}
          </div>
          <div className="mt-8 flex gap-3">
            <Button variant="ghost" onClick={() => setStep(2)}>
              Back
            </Button>
            <Button disabled={!voice} onClick={() => setStep(4)}>
              Continue
            </Button>
          </div>
        </div>
      )}

      {step === 4 && (
        <div className="mt-4">
          <h1 className="font-display text-2xl">Pick an avatar</h1>
          <div className="mt-6 flex flex-wrap gap-3">
            {AVATARS.map((a) => (
              <button
                key={a}
                onClick={() => setAvatar(a)}
                className={`flex h-14 w-14 items-center justify-center rounded-full border text-2xl transition-colors ${
                  avatar === a
                    ? "border-amber bg-amber/10"
                    : "border-rule-dark hover:border-paper/40"
                }`}
              >
                {a}
              </button>
            ))}
          </div>
          <div className="mt-8 flex gap-3">
            <Button variant="ghost" onClick={() => setStep(3)}>
              Back
            </Button>
            <Button disabled={!avatar} onClick={() => setStep(5)}>
              Continue
            </Button>
          </div>
        </div>
      )}

      {step === 5 && (
        <div className="mt-4">
          <h1 className="font-display text-2xl">Which language should they reply in?</h1>
          <div className="mt-6 flex flex-wrap gap-3">
            {(
              [
                { value: "en", label: "English" },
                { value: "bn", label: "বাংলা" },
              ] as const
            ).map((opt) => (
              <button
                key={opt.value}
                onClick={() => setLanguage(opt.value)}
                className={`rounded-full border px-5 py-2 text-sm transition-colors ${
                  language === opt.value
                    ? "border-amber bg-amber/10 text-amber"
                    : "border-rule-dark hover:border-paper/40"
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
          {error && <p className="mt-4 text-sm text-red">{error}</p>}
          <div className="mt-8 flex gap-3">
            <Button variant="ghost" onClick={() => setStep(4)}>
              Back
            </Button>
            <Button disabled={!language || submitting} onClick={finish}>
              {submitting ? "Creating…" : "Create tutor"}
            </Button>
          </div>
        </div>
      )}
    </main>
  );
}
