import { type ButtonHTMLAttributes } from "react";

type Variant = "primary" | "ghost" | "paper";

export function Button({
  variant = "primary",
  className = "",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }) {
  const base =
    "inline-flex items-center justify-center gap-2 rounded-full px-6 py-3 text-sm font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber";

  const variants: Record<Variant, string> = {
    primary: "bg-amber text-bg-ink hover:bg-amber-soft",
    ghost: "bg-transparent border border-rule-dark text-paper hover:border-amber hover:text-amber",
    paper: "bg-ink text-paper hover:bg-ink-soft",
  };

  return <button className={`${base} ${variants[variant]} ${className}`} {...props} />;
}
