"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { Fragment } from "react";
import { InlineMath, BlockMath } from "@/components/KaTeX";
import { Button } from "@/components/Button";
import { TutorAvatar, type AvatarState } from "@/components/TutorAvatar";
import { detectEmotion, PERSONALITY_BASELINE_EMOTION, type Emotion } from "@/lib/emotion";
import type { Personality } from "@/lib/tutor";

interface Tutor {
  id: string;
  name: string;
  subject: string;
  personality: string;
  voice: string;
  avatar: string;
  language: string;
}

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  had_image: boolean;
  created_at: string;
}

// Splits on $$...$$ (block) and $...$ (inline) so replies with embedded
// LaTeX (the system prompt asks the model to use this convention) render
// as real math instead of raw dollar-sign text.
function renderMessageContent(content: string) {
  const blockParts = content.split(/\$\$([\s\S]+?)\$\$/g);
  return blockParts.map((part, i) => {
    if (i % 2 === 1) {
      return (
        <div key={i} className="my-2 overflow-x-auto">
          <BlockMath math={part} />
        </div>
      );
    }
    const inlineParts = part.split(/\$(.+?)\$/g);
    return (
      <Fragment key={i}>
        {inlineParts.map((seg, j) =>
          j % 2 === 1 ? <InlineMath key={j} math={seg} /> : <span key={j}>{seg}</span>
        )}
      </Fragment>
    );
  });
}

function fileToBase64(file: File): Promise<{ base64: string; mimeType: string }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const [, base64] = result.split(",");
      resolve({ base64, mimeType: file.type });
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function speak(
  text: string,
  voicePref: string,
  lang: string,
  handlers?: { onStart?: () => void; onEnd?: () => void }
) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) {
    handlers?.onEnd?.();
    return;
  }
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = lang === "bn" ? "bn-BD" : "en-US";
  const voices = window.speechSynthesis.getVoices();
  const match = voices.find(
    (v) =>
      v.lang.startsWith(lang === "bn" ? "bn" : "en") &&
      (voicePref === "female"
        ? /female|woman/i.test(v.name)
        : voicePref === "male"
          ? /male|man/i.test(v.name)
          : true)
  );
  if (match) utterance.voice = match;
  utterance.onstart = () => handlers?.onStart?.();
  utterance.onend = () => handlers?.onEnd?.();
  utterance.onerror = () => handlers?.onEnd?.();
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(utterance);
}

interface SpeechRecognitionLike {
  lang: string;
  interimResults: boolean;
  start: () => void;
  stop: () => void;
  onresult: ((event: { results: { transcript: string }[][] }) => void) | null;
  onend: (() => void) | null;
  onerror: (() => void) | null;
}

type SpeechRecognitionCtor = new () => SpeechRecognitionLike;

declare global {
  interface Window {
    SpeechRecognition?: SpeechRecognitionCtor;
    webkitSpeechRecognition?: SpeechRecognitionCtor;
  }
}

export function ChatContent({
  tutor,
  initialMessages,
}: {
  tutor: Tutor;
  initialMessages: Message[];
}) {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [input, setInput] = useState("");
  const [photo, setPhoto] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [limitInfo, setLimitInfo] = useState<{ used: number; limit: number } | null>(null);
  const [listening, setListening] = useState(false);

  // Talking avatar: what it's doing right now, and what expression it's wearing.
  const [avatarState, setAvatarState] = useState<AvatarState>("idle");
  const [emotion, setEmotion] = useState<Emotion>(
    PERSONALITY_BASELINE_EMOTION[tutor.personality as Personality] ?? "neutral"
  );
  // "Live" hands-free voice conversation: mic -> reply -> spoken reply -> mic again, on a loop.
  const [liveMode, setLiveMode] = useState(false);

  const bottomRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);
  const liveModeRef = useRef(false);
  const localIdRef = useRef(0);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  function handlePhotoChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0] ?? null;
    setPhoto(file);
    setPhotoPreview(file ? URL.createObjectURL(file) : null);
  }

  /** Starts one round of mic capture. `onTranscript` decides what happens with the result —
   *  manual mode drops it in the text box, live mode sends it straight away. */
  function startListening(onTranscript: (transcript: string) => void) {
    const SpeechRecognition = window.SpeechRecognition ?? window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setError("Voice input isn't supported in this browser — try Chrome.");
      setLiveMode(false);
      liveModeRef.current = false;
      return;
    }
    const recognition = new SpeechRecognition();
    recognition.lang = tutor.language === "bn" ? "bn-BD" : "en-US";
    recognition.interimResults = false;
    recognition.onresult = (e: { results: { transcript: string }[][] }) => {
      onTranscript(e.results[0][0].transcript);
    };
    recognition.onend = () => {
      setListening(false);
      setAvatarState((s) => (s === "listening" ? "idle" : s));
    };
    recognition.onerror = () => {
      setListening(false);
      setAvatarState((s) => (s === "listening" ? "idle" : s));
      if (liveModeRef.current) {
        setLiveMode(false);
        liveModeRef.current = false;
      }
    };
    recognitionRef.current = recognition;
    recognition.start();
    setListening(true);
    setAvatarState("listening");
  }

  function toggleVoiceInput() {
    if (listening) {
      recognitionRef.current?.stop();
      return;
    }
    startListening((transcript) => {
      setInput((prev) => (prev ? `${prev} ${transcript}` : transcript));
    });
  }

  function toggleLiveConversation() {
    if (liveMode) {
      liveModeRef.current = false;
      setLiveMode(false);
      recognitionRef.current?.stop();
      window.speechSynthesis?.cancel();
      setAvatarState("idle");
      return;
    }
    liveModeRef.current = true;
    setLiveMode(true);
    startListening((transcript) => {
      if (transcript.trim()) sendMessage(transcript);
    });
  }

  /** Speaks a reply and, in live mode, re-opens the mic once the tutor is done talking. */
  function speakReply(text: string) {
    setAvatarState("speaking");
    speak(text, tutor.voice, tutor.language, {
      onStart: () => setAvatarState("speaking"),
      onEnd: () => {
        setAvatarState("idle");
        if (liveModeRef.current) {
          startListening((transcript) => {
            if (transcript.trim()) sendMessage(transcript);
          });
        }
      },
    });
  }

  async function sendMessage(text: string, imageFile?: File | null) {
    const trimmed = text.trim();
    if (!trimmed && !imageFile) return;

    setSending(true);
    setError(null);
    setAvatarState("thinking");

    const optimisticUser: Message = {
      id: `local-${localIdRef.current++}`,
      role: "user",
      content: trimmed || "(photo)",
      had_image: Boolean(imageFile),
      created_at: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, optimisticUser]);
    setInput("");

    try {
      let imageBase64: string | undefined;
      let imageMimeType: string | undefined;
      if (imageFile) {
        const encoded = await fileToBase64(imageFile);
        imageBase64 = encoded.base64;
        imageMimeType = encoded.mimeType;
      }
      setPhoto(null);
      setPhotoPreview(null);

      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tutorId: tutor.id,
          message: trimmed,
          imageBase64,
          imageMimeType,
        }),
      });
      const data = await res.json();

      if (res.status === 429) {
        setLimitInfo({ used: data.used, limit: data.limit });
        setError("Daily free-tier chat limit reached.");
        setAvatarState("idle");
        if (liveModeRef.current) {
          liveModeRef.current = false;
          setLiveMode(false);
        }
        return;
      }
      if (!res.ok) {
        setError(typeof data.error === "string" ? data.error : "Something went wrong.");
        setAvatarState("idle");
        return;
      }

      setMessages((prev) => [
        ...prev,
        {
          id: `local-reply-${localIdRef.current++}`,
          role: "assistant",
          content: data.reply,
          had_image: false,
          created_at: new Date().toISOString(),
        },
      ]);
      setLimitInfo(data.usage ? { used: data.usage.used, limit: data.usage.limit } : null);

      const nextEmotion = detectEmotion(
        data.reply,
        PERSONALITY_BASELINE_EMOTION[tutor.personality as Personality] ?? "neutral"
      );
      setEmotion(nextEmotion);

      // In live mode the tutor always speaks its reply out loud; otherwise only
      // the read-aloud button triggers speech, so just go back to idle.
      if (liveModeRef.current) {
        speakReply(data.reply);
      } else {
        setAvatarState("idle");
      }
    } catch {
      setError("Network error — check your connection and try again.");
      setAvatarState("idle");
    } finally {
      setSending(false);
    }
  }

  async function handleSend(e: React.FormEvent) {
    e.preventDefault();
    await sendMessage(input, photo);
  }

  return (
    <div className="mx-auto flex w-full max-w-2xl flex-1 flex-col px-6 py-6">
      <div className="flex items-center justify-between gap-3 border-b border-rule-dark pb-4">
        <Link href="/tutor" className="flex items-center gap-3">
          <TutorAvatar state={avatarState} emotion={emotion} emoji={tutor.avatar} size="sm" />
          <div>
            <p className="font-display text-lg">{tutor.name}</p>
            <p className="font-mono text-[10px] uppercase tracking-wide text-paper/50">
              {liveMode
                ? avatarState === "listening"
                  ? "Listening…"
                  : avatarState === "thinking"
                    ? "Thinking…"
                    : avatarState === "speaking"
                      ? "Speaking…"
                      : "Live conversation"
                : tutor.subject}
            </p>
          </div>
        </Link>
        <button
          type="button"
          onClick={toggleLiveConversation}
          className={`flex items-center gap-2 rounded-full border px-4 py-2 font-mono text-[10px] uppercase tracking-wide transition-colors ${
            liveMode
              ? "border-red bg-red/10 text-red"
              : "border-rule-dark text-paper/70 hover:border-amber hover:text-amber"
          }`}
        >
          {liveMode ? "◼ End call" : "📞 Talk live"}
        </button>
      </div>

      {liveMode && (
        <div className="mt-6 flex flex-col items-center gap-3 rounded-sm border border-rule-dark bg-amber/5 py-8">
          <TutorAvatar state={avatarState} emotion={emotion} emoji={tutor.avatar} size="lg" />
          <p className="font-mono text-xs uppercase tracking-wide text-paper/60">
            {avatarState === "listening"
              ? "Listening — go ahead"
              : avatarState === "thinking"
                ? `${tutor.name} is thinking…`
                : avatarState === "speaking"
                  ? `${tutor.name} is speaking…`
                  : "Starting…"}
          </p>
        </div>
      )}

      <div className="mt-4 flex-1 space-y-4 overflow-y-auto">
        {messages.length === 0 && (
          <p className="mt-8 text-center text-sm text-paper/50">
            Say hello to {tutor.name} — ask a question, or attach a photo of one.
          </p>
        )}
        {messages.map((m) => (
          <div key={m.id} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={
                m.role === "user"
                  ? "max-w-[80%] rounded-sm bg-amber/10 border border-amber/30 px-4 py-3 text-sm text-paper"
                  : "paper max-w-[80%] rounded-sm px-4 py-3 text-sm"
              }
            >
              <div className="whitespace-pre-wrap">{renderMessageContent(m.content)}</div>
              {m.role === "assistant" && (
                <button
                  type="button"
                  onClick={() => {
                    setEmotion(
                      detectEmotion(
                        m.content,
                        PERSONALITY_BASELINE_EMOTION[tutor.personality as Personality] ?? "neutral"
                      )
                    );
                    speakReply(m.content);
                  }}
                  className="mt-2 font-mono text-[10px] uppercase tracking-wide text-ink-soft hover:text-ink"
                >
                  🔊 Read aloud
                </button>
              )}
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {error && <p className="mt-3 text-sm text-red">{error}</p>}
      {limitInfo && (
        <p className="mt-2 font-mono text-xs text-paper/50">
          {limitInfo.used}/{limitInfo.limit === Infinity ? "∞" : limitInfo.limit} messages used
          today
          {limitInfo.used >= limitInfo.limit && (
            <>
              {" — "}
              <Link href="/subscription" className="text-red underline">
                upgrade to Pro
              </Link>
            </>
          )}
        </p>
      )}

      {photoPreview && (
        <div className="mt-3 flex items-center gap-3">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={photoPreview} alt="Attached" className="h-16 rounded-sm border border-rule-dark object-contain" />
          <button
            type="button"
            onClick={() => {
              setPhoto(null);
              setPhotoPreview(null);
            }}
            className="font-mono text-xs text-paper/50 underline"
          >
            Remove
          </button>
        </div>
      )}

      {!liveMode && (
        <form onSubmit={handleSend} className="mt-4 flex items-end gap-2">
          <label className="cursor-pointer rounded-full border border-rule-dark p-3 text-paper/70 hover:border-amber hover:text-amber">
            📷
            <input type="file" accept="image/*" className="hidden" onChange={handlePhotoChange} />
          </label>
          <button
            type="button"
            onClick={toggleVoiceInput}
            className={`rounded-full border p-3 transition-colors ${
              listening
                ? "border-amber bg-amber/10 text-amber"
                : "border-rule-dark text-paper/70 hover:border-amber hover:text-amber"
            }`}
          >
            🎤
          </button>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSend(e);
              }
            }}
            rows={1}
            placeholder={`Message ${tutor.name}…`}
            className="flex-1 resize-none rounded-sm border border-rule-dark bg-transparent px-3 py-3 text-sm outline-none focus:border-amber"
          />
          <Button type="submit" disabled={sending || (!input.trim() && !photo)}>
            {sending ? "…" : "Send"}
          </Button>
        </form>
      )}
    </div>
  );
}
