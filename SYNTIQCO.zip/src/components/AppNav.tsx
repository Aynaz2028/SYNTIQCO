import Link from "next/link";

export function AppNav({
  active,
}: {
  active:
    | "dashboard"
    | "solver"
    | "practice"
    | "youtube"
    | "tutor"
    | "history"
    | "subscription"
    | "profile";
}) {
  const links = [
    { href: "/dashboard", label: "Today", key: "dashboard" },
    { href: "/solver", label: "AI Solver", key: "solver" },
    { href: "/practice", label: "Practice", key: "practice" },
    { href: "/youtube", label: "YouTube", key: "youtube" },
    { href: "/tutor", label: "Tutor", key: "tutor" },
    { href: "/history", label: "Memory", key: "history" },
    { href: "/subscription", label: "Plans", key: "subscription" },
    { href: "/profile", label: "Profile", key: "profile" },
  ] as const;

  return (
    <header className="border-b border-rule-dark">
      <div className="mx-auto flex max-w-4xl items-center justify-between px-6 py-4">
        <Link href="/dashboard" className="font-display text-lg italic">
          HabitFirst
        </Link>
        <nav className="flex gap-5 font-mono text-xs uppercase tracking-wide">
          {links.map((link) => (
            <Link
              key={link.key}
              href={link.href}
              className={active === link.key ? "text-amber" : "text-paper/60 hover:text-paper"}
            >
              {link.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}
