"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { StreakBadge } from "@/components/StreakBadge";
import { MissionCard } from "@/components/MissionCard";
import { NotificationOptIn } from "@/components/NotificationOptIn";

interface Streak {
  current_streak: number;
  longest_streak: number;
  badges: string[];
}

export function DashboardContent({
  initialStreak,
  vapidPublicKey,
}: {
  initialStreak: Streak;
  vapidPublicKey: string | null;
}) {
  const [streak, setStreak] = useState(initialStreak);
  const [greeting, setGreeting] = useState<string | null>(null);
  const [celebrating, setCelebrating] = useState(false);

  useEffect(() => {
    fetch("/api/greeting")
      .then((res) => res.json())
      .then((data) => setGreeting(data.greeting ?? null))
      .catch(() => setGreeting(null));
  }, []);

  return (
    <div className="mx-auto max-w-2xl px-6 py-10">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="font-mono text-xs uppercase tracking-widest text-amber">Today</p>
          <h1 className="mt-1 font-display text-2xl italic">
            {greeting ?? "Loading your daily briefing…"}
          </h1>
        </div>
        <div className="flex flex-col items-end gap-2">
          <StreakBadge currentStreak={streak.current_streak} badges={streak.badges} />
          <NotificationOptIn vapidPublicKey={vapidPublicKey} />
        </div>
      </div>

      {celebrating && (
        <div className="mt-6 rounded-sm border border-green bg-green/10 px-5 py-4 text-sm">
          Mission complete — streak now at {streak.current_streak} day
          {streak.current_streak === 1 ? "" : "s"}. See you tomorrow.
        </div>
      )}

      <Link
        href="/tutor"
        className="paper-dark mt-6 flex items-center justify-between gap-4 rounded-sm px-5 py-4 transition-opacity hover:opacity-90"
      >
        <div>
          <p className="font-mono text-[10px] uppercase tracking-wide text-paper/60">
            AI Tutor
          </p>
          <p className="mt-0.5 font-display text-lg">Continue a conversation →</p>
        </div>
        <span className="text-2xl">💬</span>
      </Link>

      <div className="mt-8">
        <MissionCard
          onAllDone={(newStreak) => {
            if (
              newStreak &&
              typeof newStreak === "object" &&
              "current_streak" in newStreak
            ) {
              setStreak(newStreak as Streak);
            }
            setCelebrating(true);
          }}
        />
      </div>
    </div>
  );
}
