"use client";

import { useState } from "react";
import { MarginMark } from "@/components/MarginMark";
import { Button } from "@/components/Button";
import {
  PAYMENT_METHODS,
  PLAN_FEATURES,
  PRICE_BY_TIER,
  PRO_PRICE_LABEL,
  TIER_LABELS,
  VIP_PRICE_LABEL,
  type Tier,
} from "@/lib/tiers";

interface PaymentRow {
  id: string;
  tier: string;
  amount: number;
  payment_method: string | null;
  status: string;
  created_at: string;
}

type Status = "success" | "pending" | "canceled" | "error" | null;

const PAYABLE_TIERS: { id: "pro" | "vip"; label: string; price: string; blurb: string }[] = [
  { id: "pro", label: "Pro", price: PRO_PRICE_LABEL, blurb: "Unlimited solves, chat, and full memory history." },
  { id: "vip", label: "VIP", price: VIP_PRICE_LABEL, blurb: "Everything in Pro, plus priority AI responses and early access to new features." },
];

export function SubscriptionContent({
  currentTier,
  tierExpiresAt,
  payments,
  initialStatus,
}: {
  currentTier: Tier;
  tierExpiresAt: string | null;
  payments: PaymentRow[];
  initialStatus: Status;
}) {
  const [status, setStatus] = useState<Status>(initialStatus);
  const [selectedTier, setSelectedTier] = useState<"pro" | "vip">(currentTier === "vip" ? "pro" : "vip");
  const [selectedMethod, setSelectedMethod] = useState<string>(PAYMENT_METHODS[0].id);
  const [starting, setStarting] = useState(false);
  const [checkoutError, setCheckoutError] = useState<string | null>(null);

  async function startCheckout() {
    setStarting(true);
    setCheckoutError(null);
    setStatus(null);
    try {
      const res = await fetch("/api/subscription/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tier: selectedTier, paymentMethod: selectedMethod }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Checkout failed");
      window.location.href = data.paymentUrl;
    } catch (err) {
      setCheckoutError(err instanceof Error ? err.message : "Couldn't start checkout.");
      setStarting(false);
    }
  }

  return (
    <div className="mx-auto max-w-2xl px-6 py-10">
      <p className="font-mono text-xs uppercase tracking-widest text-amber">Subscription</p>
      <h1 className="mt-1 font-display text-2xl italic">
        You&apos;re on {TIER_LABELS[currentTier]}
        {currentTier !== "free" && tierExpiresAt && (
          <span className="text-paper/60">
            {" "}
            · renews {new Date(tierExpiresAt).toLocaleDateString()}
          </span>
        )}
      </h1>

      {status && (
        <div className="mt-4 flex items-center gap-3 rounded-sm border border-rule-dark px-5 py-4">
          <MarginMark
            label={status === "success" ? "done" : status === "pending" ? "wait" : "note"}
            variant={status === "success" ? "green" : undefined}
          />
          <p className="text-sm text-paper/70">
            {status === "success" && "Payment confirmed — your plan is updated."}
            {status === "pending" && "Payment received, waiting on gateway confirmation. Refresh in a moment."}
            {status === "canceled" && "Checkout was canceled — no charge was made."}
            {status === "error" && "Something went wrong confirming that payment. If you were charged, contact support."}
          </p>
        </div>
      )}

      {/* Feature comparison */}
      <div className="paper mt-8 rounded-sm p-6">
        <div className="grid grid-cols-4 gap-3 border-b border-rule pb-3 font-mono text-xs uppercase tracking-wide text-ink-soft">
          <span>Feature</span>
          <span>Free</span>
          <span>Pro</span>
          <span>VIP</span>
        </div>
        {PLAN_FEATURES.map((f) => (
          <div
            key={f.label}
            className="grid grid-cols-4 gap-3 border-b border-rule py-3 text-sm last:border-none"
          >
            <span className="text-ink">{f.label}</span>
            <span className="text-ink-soft">{f.free}</span>
            <span className="text-ink-soft">{f.pro}</span>
            <span className="font-medium text-ink">{f.vip}</span>
          </div>
        ))}
      </div>

      {/* Payment options */}
      <section className="paper mt-6 rounded-sm p-6">
        <h2 className="font-mono text-xs uppercase tracking-wide text-ink-soft">Payment options</h2>

        <p className="mt-3 text-sm text-ink-soft">Plan</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {PAYABLE_TIERS.map((p) => (
            <button
              key={p.id}
              type="button"
              disabled={currentTier === p.id}
              onClick={() => setSelectedTier(p.id)}
              className={`rounded-full border px-4 py-2 text-sm transition-colors disabled:opacity-40 ${
                selectedTier === p.id
                  ? "border-amber bg-amber/10 text-amber"
                  : "border-rule text-ink-soft hover:border-ink/40"
              }`}
            >
              {p.label} · {p.price}
              {currentTier === p.id ? " (current)" : ""}
            </button>
          ))}
        </div>
        <p className="mt-2 text-xs text-ink-soft">
          {PAYABLE_TIERS.find((p) => p.id === selectedTier)?.blurb}
        </p>

        <p className="mt-5 text-sm text-ink-soft">Pay with</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {PAYMENT_METHODS.map((m) => (
            <button
              key={m.id}
              type="button"
              onClick={() => setSelectedMethod(m.id)}
              className={`rounded-full border px-4 py-2 text-sm transition-colors ${
                selectedMethod === m.id
                  ? "border-amber bg-amber/10 text-amber"
                  : "border-rule text-ink-soft hover:border-ink/40"
              }`}
            >
              {m.label}
            </button>
          ))}
        </div>
        <p className="mt-2 text-xs text-ink-soft">
          You&apos;ll pick and confirm the exact channel on the secure UddoktaPay checkout page.
        </p>

        <div className="mt-6 flex items-center gap-4">
          <Button onClick={startCheckout} disabled={starting || currentTier === selectedTier}>
            {starting ? "Starting checkout…" : `Pay ${PRICE_BY_TIER[selectedTier]} ৳ for ${TIER_LABELS[selectedTier]}`}
          </Button>
          {checkoutError && <p className="text-sm text-red">{checkoutError}</p>}
        </div>
      </section>

      {/* Payment history */}
      {payments.length > 0 && (
        <section className="paper mt-6 rounded-sm p-6">
          <h2 className="font-mono text-xs uppercase tracking-wide text-ink-soft">Recent payments</h2>
          <div className="mt-3 divide-y divide-rule">
            {payments.map((p) => (
              <div key={p.id} className="flex items-center justify-between gap-4 py-3 text-sm">
                <div>
                  <p className="text-ink">
                    {TIER_LABELS[p.tier as Tier] ?? p.tier} · ৳{p.amount}
                  </p>
                  <p className="text-xs text-ink-soft">
                    {new Date(p.created_at).toLocaleDateString()}
                    {p.payment_method ? ` · ${p.payment_method}` : ""}
                  </p>
                </div>
                <span
                  className={`font-mono text-xs uppercase tracking-wide ${
                    p.status === "completed"
                      ? "text-green"
                      : p.status === "failed" || p.status === "cancelled"
                        ? "text-red"
                        : "text-ink-soft"
                  }`}
                >
                  {p.status}
                </span>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
