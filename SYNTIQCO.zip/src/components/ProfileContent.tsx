"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { MarginMark } from "@/components/MarginMark";
import { TIER_LABELS, type Tier } from "@/lib/tiers";

interface ProfileData {
  student: {
    fullName: string | null;
    track: string | null;
    level: string | null;
    subjects: string[];
    tier: string;
  };
  stats: {
    currentStreak: number;
    longestStreak: number;
    totalWeakPointsLogged: number;
    totalReviewed: number;
    totalSolverUses: number;
    totalQuizzes: number;
    quizAccuracyPct: number | null;
  };
  subjectProgress: {
    subject: string;
    totalWeakPoints: number;
    masteredWeakPoints: number;
    masteryPct: number;
  }[];
  badges: string[];
  certificates: { id: string; subject: string; title: string; issued_at: string }[];
}

const MILESTONE_LABELS: Record<string, string> = {
  "7_day": "7-day streak",
  "14_day": "14-day streak",
  "30_day": "30-day streak",
};

function badgeLabel(badge: string) {
  if (MILESTONE_LABELS[badge]) return MILESTONE_LABELS[badge];
  if (badge.endsWith("_mastered")) {
    const subject = badge.slice(0, -"_mastered".length).replace(/_/g, " ");
    return `${subject} mastered`.replace(/\b\w/g, (c) => c.toUpperCase());
  }
  return badge;
}

const LEVEL_LABELS: Record<string, string> = {
  ssc: "SSC",
  hsc: "HSC",
  o_level: "O Level",
  a_level: "A Level",
};

const TRACK_LABELS: Record<string, string> = {
  nctb: "NCTB",
  cambridge_edexcel: "Cambridge / Edexcel",
};

function StatCard({ value, label }: { value: string | number; label: string }) {
  return (
    <div className="paper rounded-sm p-4 text-center">
      <p className="font-display text-2xl">{value}</p>
      <p className="mt-1 font-mono text-[10px] uppercase tracking-wide text-ink-soft">{label}</p>
    </div>
  );
}

export function ProfileContent() {
  const [data, setData] = useState<ProfileData | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/profile")
      .then(async (res) => {
        if (!res.ok) throw new Error((await res.json()).error ?? "Failed to load");
        return res.json();
      })
      .then(setData)
      .catch((err) => setError(err.message));
  }, []);

  return (
    <div className="mx-auto max-w-2xl px-6 py-10">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="font-mono text-xs uppercase tracking-widest text-amber">Profile</p>
          <h1 className="mt-1 font-display text-2xl italic">
            {data?.student.fullName ?? "Your profile"}
          </h1>
          {data?.student.track && (
            <p className="mt-1 text-sm text-paper/60">
              {TRACK_LABELS[data.student.track] ?? data.student.track} ·{" "}
              {LEVEL_LABELS[data.student.level ?? ""] ?? data.student.level} ·{" "}
              {TIER_LABELS[data.student.tier as Tier] ?? "Free"}
            </p>
          )}
        </div>
        <div className="flex shrink-0 gap-2">
          <Link
            href="/notifications"
            className="rounded-full border border-rule-dark px-4 py-2 font-mono text-xs uppercase tracking-wide text-paper/70 hover:border-amber hover:text-amber"
          >
            Notifications
          </Link>
          <Link
            href="/settings"
            className="rounded-full border border-rule-dark px-4 py-2 font-mono text-xs uppercase tracking-wide text-paper/70 hover:border-amber hover:text-amber"
          >
            Settings
          </Link>
        </div>
      </div>

      {error && <p className="mt-6 text-sm text-red">{error}</p>}
      {!data && !error && <p className="mt-6 text-sm text-paper/60">Loading your profile…</p>}

      {data && (
        <>
          {/* Learning statistics */}
          <section className="mt-8">
            <h2 className="font-mono text-xs uppercase tracking-wide text-paper/50">
              Learning Statistics
            </h2>
            <div className="mt-3 grid grid-cols-3 gap-3">
              <StatCard value={data.stats.currentStreak} label="Day streak" />
              <StatCard value={data.stats.longestStreak} label="Best streak" />
              <StatCard value={data.stats.totalSolverUses} label="Solver uses" />
              <StatCard value={data.stats.totalWeakPointsLogged} label="Points logged" />
              <StatCard value={data.stats.totalReviewed} label="Points reviewed" />
              <StatCard
                value={data.stats.quizAccuracyPct !== null ? `${data.stats.quizAccuracyPct}%` : "—"}
                label={`Quiz accuracy${data.stats.totalQuizzes ? ` (${data.stats.totalQuizzes})` : ""}`}
              />
            </div>
          </section>

          {/* Certificates */}
          <section className="mt-8">
            <h2 className="font-mono text-xs uppercase tracking-wide text-paper/50">
              Certificates
            </h2>
            {data.certificates.length === 0 ? (
              <p className="mt-3 text-sm text-paper/60">
                Clear a subject&apos;s weak-point backlog to earn a certificate for it.
              </p>
            ) : (
              <div className="mt-3 space-y-3">
                {data.certificates.map((c) => (
                  <div
                    key={c.id}
                    className="paper flex items-center justify-between gap-4 rounded-sm p-5"
                  >
                    <div>
                      <p className="font-display text-lg">{c.title}</p>
                      <p className="mt-1 text-xs text-ink-soft">
                        Issued {new Date(c.issued_at).toLocaleDateString()}
                      </p>
                    </div>
                    <MarginMark label="cert" variant="green" />
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Badges */}
          <section className="mt-8">
            <h2 className="font-mono text-xs uppercase tracking-wide text-paper/50">Badges</h2>
            {data.badges.length === 0 ? (
              <p className="mt-3 text-sm text-paper/60">
                Keep your streak alive and clear a subject&apos;s backlog to earn your first badge.
              </p>
            ) : (
              <div className="mt-3 flex flex-wrap gap-2">
                {data.badges.map((b) => (
                  <span
                    key={b}
                    className="rounded-full border border-amber px-3 py-1.5 font-mono text-[10px] uppercase tracking-wide text-amber"
                  >
                    {badgeLabel(b)}
                  </span>
                ))}
              </div>
            )}
          </section>

          {/* AI Memory Progress */}
          <section className="mt-8">
            <h2 className="font-mono text-xs uppercase tracking-wide text-paper/50">
              AI Memory Progress
            </h2>
            {data.subjectProgress.length === 0 ? (
              <div className="paper mt-3 rounded-sm p-6 text-center text-sm text-ink-soft">
                Once the AI Solver or a quiz catches a mistake, subject-by-subject progress
                shows up here.
              </div>
            ) : (
              <div className="mt-3 space-y-3">
                {data.subjectProgress.map((s) => (
                  <div key={s.subject} className="paper rounded-sm p-5">
                    <div className="flex items-center justify-between gap-4">
                      <p className="font-display text-lg">{s.subject}</p>
                      <p className="font-mono text-xs text-ink-soft">
                        {s.masteredWeakPoints}/{s.totalWeakPoints} mastered
                      </p>
                    </div>
                    <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-ink/10">
                      <div
                        className="h-full bg-green"
                        style={{ width: `${Math.max(0, Math.min(100, s.masteryPct))}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        </>
      )}
    </div>
  );
}
