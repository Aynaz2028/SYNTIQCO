import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getSettings } from "@/lib/settings";
import { NotificationsContent } from "@/components/NotificationsContent";

export default async function NotificationsPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: student } = await supabase
    .from("students")
    .select("onboarding_completed_at")
    .eq("id", user.id)
    .maybeSingle();
  if (!student?.onboarding_completed_at) redirect("/onboarding");

  const settings = await getSettings(supabase, user.id);

  return (
    <div className="min-h-screen">
      <NotificationsContent initialSettings={settings} />
    </div>
  );
}
