"use client";

import { useState } from "react";
import { InlineMath, BlockMath } from "@/components/KaTeX";
import { AppNav } from "@/components/AppNav";
import { Button } from "@/components/Button";
import { MarginMark } from "@/components/MarginMark";
import Link from "next/link";

interface SolverStep {
  step: number;
  explanation: string;
  latex: string;
}

interface SolverResult {
  topicGuess: { subject: string; topic: string; subtopic: string | null };
  steps: SolverStep[];
  finalAnswerLatex: string;
}

function fileToBase64(file: File): Promise<{ base64: string; mimeType: string }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const [, base64] = result.split(",");
      resolve({ base64, mimeType: file.type });
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export default function SolverPage() {
  const [questionText, setQuestionText] = useState("");
  const [subjectHint, setSubjectHint] = useState("");
  const [wasFirstAttemptWrong, setWasFirstAttemptWrong] = useState(false);
  const [photo, setPhoto] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [limitInfo, setLimitInfo] = useState<{ used: number; limit: number } | null>(null);
  const [result, setResult] = useState<SolverResult | null>(null);

  function handlePhotoChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0] ?? null;
    setPhoto(file);
    setPhotoPreview(file ? URL.createObjectURL(file) : null);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!questionText.trim() && !photo) return;

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      let imageBase64: string | undefined;
      let imageMimeType: string | undefined;
      if (photo) {
        const encoded = await fileToBase64(photo);
        imageBase64 = encoded.base64;
        imageMimeType = encoded.mimeType;
      }

      const res = await fetch("/api/solver", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          questionText,
          subjectHint: subjectHint || undefined,
          inputType: photo ? "photo" : "typed",
          wasFirstAttemptWrong,
          imageBase64,
          imageMimeType,
        }),
      });
      const data = await res.json();

      if (res.status === 429) {
        setLimitInfo({ used: data.used, limit: data.limit });
        setError("Daily free-tier Solver limit reached.");
        return;
      }
      if (!res.ok) {
        setError(typeof data.error === "string" ? data.error : "Something went wrong.");
        return;
      }

      setResult(data.result);
      setLimitInfo(data.usage ? { used: data.usage.used, limit: data.usage.limit } : null);
    } catch {
      setError("Network error — check your connection and try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen">
      <AppNav active="solver" />
      <div className="mx-auto max-w-2xl px-6 py-10">
        <p className="font-mono text-xs uppercase tracking-widest text-amber">AI Solver</p>
        <h1 className="mt-1 font-display text-2xl italic">
          Step-by-step solutions, marked the way your board marks
        </h1>
        <p className="mt-2 text-sm text-paper/60">
          Type a question or upload a photo. Explanations follow NCTB or Cambridge/Edexcel
          mark-scheme conventions based on your curriculum track.
        </p>

        <form onSubmit={handleSubmit} className="paper mt-8 rounded-sm p-6">
          <label className="text-sm text-ink">
            Question
            <textarea
              value={questionText}
              onChange={(e) => setQuestionText(e.target.value)}
              rows={4}
              placeholder="e.g. Solve for x: 2x² - 5x + 3 = 0"
              className="mt-1 w-full rounded-sm border border-rule bg-transparent px-3 py-2 text-ink outline-none focus:border-ink/40"
            />
          </label>

          <div className="mt-4 flex flex-wrap items-center gap-4">
            <label className="cursor-pointer font-mono text-xs uppercase tracking-wide text-ink-soft underline">
              {photo ? "Change photo" : "Attach a photo instead"}
              <input type="file" accept="image/*" className="hidden" onChange={handlePhotoChange} />
            </label>
            <input
              value={subjectHint}
              onChange={(e) => setSubjectHint(e.target.value)}
              placeholder="Subject (optional)"
              className="rounded-sm border border-rule bg-transparent px-3 py-1.5 text-sm text-ink outline-none focus:border-ink/40"
            />
          </div>

          {photoPreview && (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={photoPreview}
              alt="Uploaded question"
              className="mt-4 max-h-48 rounded-sm border border-rule object-contain"
            />
          )}

          <label className="mt-4 flex items-center gap-2 text-xs text-ink-soft">
            <input
              type="checkbox"
              checked={wasFirstAttemptWrong}
              onChange={(e) => setWasFirstAttemptWrong(e.target.checked)}
            />
            I got this wrong on my first attempt — log it as a weak point
          </label>

          {error && <p className="mt-4 text-sm text-red">{error}</p>}
          {limitInfo && (
            <p className="mt-2 font-mono text-xs text-ink-soft">
              {limitInfo.used}/{limitInfo.limit === Infinity ? "∞" : limitInfo.limit} solves used
              today
              {limitInfo.used >= limitInfo.limit && (
                <>
                  {" — "}
                  <Link href="/subscription" className="text-red underline">
                    upgrade to Pro
                  </Link>
                </>
              )}
            </p>
          )}

          <Button type="submit" className="mt-5" disabled={loading}>
            {loading ? "Solving…" : "Solve it"}
          </Button>
        </form>

        {result && (
          <div className="paper mt-6 rounded-sm p-6">
            <p className="font-mono text-xs uppercase tracking-wide text-ink-soft">
              {result.topicGuess.subject} — {result.topicGuess.topic}
              {result.topicGuess.subtopic ? ` (${result.topicGuess.subtopic})` : ""}
            </p>

            <div className="mt-4 space-y-4">
              {result.steps.map((step) => (
                <div key={step.step} className="flex gap-3">
                  <MarginMark label={`${step.step}`} />
                  <div>
                    <p className="text-sm">{step.explanation}</p>
                    {step.latex && (
                      <div className="mt-1 overflow-x-auto">
                        <BlockMath math={step.latex} />
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {result.finalAnswerLatex && (
              <div className="mt-6 flex items-center gap-3 border-t border-rule pt-4">
                <MarginMark label="✓" variant="green" />
                <span className="font-display text-lg">
                  <InlineMath math={result.finalAnswerLatex} />
                </span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
