import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { AppNav } from "@/components/AppNav";
import { ProfileContent } from "@/components/ProfileContent";

export default async function ProfilePage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: student } = await supabase
    .from("students")
    .select("onboarding_completed_at")
    .eq("id", user.id)
    .maybeSingle();
  if (!student?.onboarding_completed_at) redirect("/onboarding");

  return (
    <div className="min-h-screen">
      <AppNav active="profile" />
      <ProfileContent />
    </div>
  );
}
