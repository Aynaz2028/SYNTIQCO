"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/Button";

export default function SignupPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const supabase = createClient();
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { emailRedirectTo: `${window.location.origin}/api/auth/callback` },
    });
    setLoading(false);
    if (error) {
      setError(error.message);
      return;
    }
    // If email confirmation is off in the Supabase project, there's already a session.
    if (data.session) {
      router.replace("/onboarding");
      router.refresh();
      return;
    }
    setSent(true);
  }

  if (sent) {
    return (
      <main className="mx-auto flex min-h-screen max-w-sm flex-col justify-center px-6 text-center">
        <h1 className="font-display text-2xl">Check your inbox</h1>
        <p className="mt-3 text-sm text-paper/70">
          We sent a confirmation link to <strong>{email}</strong>. Follow it to finish setting up
          your account.
        </p>
      </main>
    );
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-sm flex-col justify-center px-6">
      <Link href="/" className="mb-8 font-display text-xl italic">
        HabitFirst
      </Link>
      <h1 className="font-display text-2xl">Start your first streak</h1>
      <form onSubmit={handleSubmit} className="mt-8 flex flex-col gap-4">
        <label className="text-sm">
          Email
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="mt-1 w-full rounded-sm border border-rule-dark bg-transparent px-3 py-2 text-paper outline-none focus:border-amber"
          />
        </label>
        <label className="text-sm">
          Password
          <input
            type="password"
            required
            minLength={6}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="mt-1 w-full rounded-sm border border-rule-dark bg-transparent px-3 py-2 text-paper outline-none focus:border-amber"
          />
        </label>
        {error && <p className="text-sm text-red">{error}</p>}
        <Button type="submit" disabled={loading} className="mt-2">
          {loading ? "Creating account…" : "Create free account"}
        </Button>
      </form>
      <p className="mt-6 text-sm text-paper/60">
        Already have an account?{" "}
        <Link href="/login" className="text-amber underline">
          Log in
        </Link>
      </p>
    </main>
  );
}
