import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { buildContextualGreeting } from "@/lib/memory-engine";

export async function GET() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const { data: student } = await supabase
    .from("students")
    .select("full_name")
    .eq("id", user.id)
    .single();

  const firstName = (student?.full_name ?? "there").split(" ")[0];

  try {
    const greeting = await buildContextualGreeting(supabase, user.id, firstName);
    return NextResponse.json({ greeting });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 500 });
  }
}
