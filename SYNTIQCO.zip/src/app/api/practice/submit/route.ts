import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { submitMcqPractice, submitWrittenPractice } from "@/lib/practice";
import type { CurriculumTrack } from "@/lib/curriculum";

const bodySchema = z.discriminatedUnion("mode", [
  z.object({
    mode: z.literal("mcq"),
    subject: z.string().min(1),
    topic: z.string().min(1),
    subtopic: z.string().nullable().optional(),
    question: z.string().min(1),
    answerIndex: z.number().int().min(0),
    selectedIndex: z.number().int().min(0),
  }),
  z.object({
    mode: z.literal("written"),
    subject: z.string().min(1),
    topic: z.string().min(1),
    subtopic: z.string().nullable().optional(),
    question: z.string().min(1),
    maxMarks: z.number().int().min(1),
    modelAnswer: z.string().min(1),
    studentAnswer: z.string().max(4000).default(""),
  }),
]);

export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const { data: student } = await supabase
    .from("students")
    .select("curriculum_track")
    .eq("id", user.id)
    .single();
  if (!student) return NextResponse.json({ error: "Complete onboarding first" }, { status: 400 });

  const parsed = bodySchema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const body = parsed.data;

  try {
    if (body.mode === "mcq") {
      const result = await submitMcqPractice(supabase, {
        studentId: user.id,
        subject: body.subject,
        topic: body.topic,
        subtopic: body.subtopic,
        question: body.question,
        answerIndex: body.answerIndex,
        selectedIndex: body.selectedIndex,
      });
      return NextResponse.json(result);
    }

    const grade = await submitWrittenPractice(supabase, {
      studentId: user.id,
      subject: body.subject,
      topic: body.topic,
      subtopic: body.subtopic,
      question: body.question,
      maxMarks: body.maxMarks,
      modelAnswer: body.modelAnswer,
      studentAnswer: body.studentAnswer,
      track: student.curriculum_track as CurriculumTrack,
    });
    return NextResponse.json(grade);
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 500 });
  }
}
