import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { generatePracticeItem } from "@/lib/practice";
import { checkAndIncrementPracticeUsage } from "@/lib/rate-limit";
import { effectiveTier } from "@/lib/tiers";
import type { CurriculumTrack } from "@/lib/curriculum";

const bodySchema = z.object({
  subject: z.string().min(1).max(80),
  topic: z.string().min(1).max(120),
  subtopic: z.string().max(120).optional(),
  mode: z.enum(["mcq", "written"]),
});

export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const { data: student } = await supabase
    .from("students")
    .select("tier, tier_expires_at, timezone, curriculum_track")
    .eq("id", user.id)
    .single();
  if (!student) return NextResponse.json({ error: "Complete onboarding first" }, { status: 400 });

  const tier = effectiveTier(student.tier, student.tier_expires_at);

  const parsed = bodySchema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const { subject, topic, subtopic, mode } = parsed.data;

  // Server-side enforcement — this is the real gate; the UI counter is
  // just a courtesy display and cannot be relied on by itself.
  const usage = await checkAndIncrementPracticeUsage(
    supabase,
    user.id,
    tier,
    student.timezone
  );
  if (!usage.allowed) {
    return NextResponse.json(
      {
        error: "Daily free-tier Practice limit reached",
        used: usage.used,
        limit: usage.limit,
        upgradeUrl: "/subscription",
      },
      { status: 429 }
    );
  }

  try {
    const item = await generatePracticeItem({
      subject,
      topic,
      subtopic,
      track: student.curriculum_track as CurriculumTrack,
      mode,
    });

    // Same trust model as the daily mission's mcq_ref: the answer key
    // (answerIndex, or modelAnswer for written mode) travels with the item
    // but the UI never renders it until after the student submits.
    return NextResponse.json({ item, usage });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 500 });
  }
}
