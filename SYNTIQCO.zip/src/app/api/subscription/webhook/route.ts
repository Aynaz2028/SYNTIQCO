import { NextResponse } from "next/server";
import { isValidWebhookApiKey } from "@/lib/payments";
import { finalizePayment } from "@/lib/subscription";

/**
 * UddoktaPay IPN — sends the same RT-UDDOKTAPAY-API-KEY header as the
 * checkout API, which we validate per their "Validate Webhook" guide before
 * trusting the payload. This is a secondary, server-to-server confirmation
 * channel alongside the redirect-based callback route; finalizePayment() is
 * idempotent, so whichever arrives first wins and the second is a no-op.
 */
export async function POST(request: Request) {
  const headerKey = request.headers.get("RT-UDDOKTAPAY-API-KEY");
  if (!isValidWebhookApiKey(headerKey)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const payload = await request.json().catch(() => null);
  const invoiceId = payload?.invoice_id;
  if (!invoiceId || typeof invoiceId !== "string") {
    return NextResponse.json({ error: "Missing invoice_id" }, { status: 400 });
  }

  const result = await finalizePayment(invoiceId);
  if (!result.ok) {
    return NextResponse.json({ error: result.reason }, { status: 404 });
  }

  return NextResponse.json({ ok: true });
}
