import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { createCharge } from "@/lib/payments";
import { PRICE_BY_TIER } from "@/lib/tiers";

const bodySchema = z.object({
  tier: z.enum(["pro", "vip"]),
  paymentMethod: z.enum(["bkash", "nagad", "rocket", "card"]).optional(),
});

export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const parsed = bodySchema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const { tier, paymentMethod } = parsed.data;

  const { data: student } = await supabase
    .from("students")
    .select("full_name, tier, onboarding_completed_at")
    .eq("id", user.id)
    .maybeSingle();
  if (!student?.onboarding_completed_at) {
    return NextResponse.json({ error: "Complete onboarding first" }, { status: 400 });
  }
  if (student.tier === tier) {
    return NextResponse.json({ error: `You're already on ${tier}.` }, { status: 400 });
  }

  const amount = PRICE_BY_TIER[tier];

  const { data: payment, error: insertError } = await supabase
    .from("subscription_payments")
    .insert({
      student_id: user.id,
      tier,
      amount,
      payment_method: paymentMethod ?? null,
      status: "pending",
    })
    .select("id")
    .single();

  if (insertError || !payment) {
    return NextResponse.json({ error: "Couldn't start checkout" }, { status: 500 });
  }

  const origin = new URL(request.url).origin;

  try {
    const { paymentUrl } = await createCharge({
      fullName: student.full_name ?? "HabitFirst Student",
      email: user.email ?? "",
      amount,
      reference: payment.id,
      redirectUrl: `${origin}/api/subscription/callback`,
      cancelUrl: `${origin}/subscription?canceled=1`,
      webhookUrl: `${origin}/api/subscription/webhook`,
    });

    return NextResponse.json({ paymentUrl });
  } catch (err) {
    await supabase
      .from("subscription_payments")
      .update({ status: "failed", updated_at: new Date().toISOString() })
      .eq("id", payment.id);

    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Checkout failed" },
      { status: 502 }
    );
  }
}
