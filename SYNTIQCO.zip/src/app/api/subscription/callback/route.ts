import { NextResponse } from "next/server";
import { finalizePayment } from "@/lib/subscription";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const invoiceId = url.searchParams.get("invoice_id");
  const subscriptionUrl = new URL("/subscription", url.origin);

  if (!invoiceId) {
    subscriptionUrl.searchParams.set("error", "missing_invoice");
    return NextResponse.redirect(subscriptionUrl);
  }

  const result = await finalizePayment(invoiceId);

  if (!result.ok) {
    subscriptionUrl.searchParams.set("error", result.reason);
    return NextResponse.redirect(subscriptionUrl);
  }

  subscriptionUrl.searchParams.set(result.completed ? "success" : "pending", "1");
  return NextResponse.redirect(subscriptionUrl);
}

// UddoktaPay's `return_type` can also be "POST" depending on gateway config —
// handle it the same way rather than assuming GET always applies.
export async function POST(request: Request) {
  const form = await request.formData().catch(() => null);
  const invoiceId = form?.get("invoice_id")?.toString();
  const url = new URL(request.url);
  const subscriptionUrl = new URL("/subscription", url.origin);

  if (!invoiceId) {
    subscriptionUrl.searchParams.set("error", "missing_invoice");
    return NextResponse.redirect(subscriptionUrl);
  }

  const result = await finalizePayment(invoiceId);
  if (!result.ok) {
    subscriptionUrl.searchParams.set("error", result.reason);
    return NextResponse.redirect(subscriptionUrl);
  }

  subscriptionUrl.searchParams.set(result.completed ? "success" : "pending", "1");
  return NextResponse.redirect(subscriptionUrl);
}
