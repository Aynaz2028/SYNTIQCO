import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { chatWithTutor, type ChatTurn } from "@/lib/gemini";
import { checkAndIncrementChatUsage } from "@/lib/rate-limit";
import { effectiveTier } from "@/lib/tiers";
import { PERSONALITY_SYSTEM_HINT, type Personality } from "@/lib/tutor";
import { MARK_SCHEME_STYLE, type CurriculumTrack } from "@/lib/curriculum";

const HISTORY_TURNS = 20;

const postSchema = z
  .object({
    tutorId: z.string().uuid(),
    message: z.string().max(4000).optional().default(""),
    imageBase64: z.string().optional(),
    imageMimeType: z.string().optional(),
  })
  .refine((v) => v.message.trim().length > 0 || (v.imageBase64 && v.imageMimeType), {
    message: "Type a message or attach an image.",
  });

async function loadTutor(
  supabase: Awaited<ReturnType<typeof createClient>>,
  tutorId: string,
  studentId: string
) {
  const { data } = await supabase
    .from("tutors")
    .select("id, name, subject, personality, voice, avatar, language")
    .eq("id", tutorId)
    .eq("student_id", studentId)
    .maybeSingle();
  return data;
}

export async function GET(request: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const tutorId = new URL(request.url).searchParams.get("tutorId");
  if (!tutorId) return NextResponse.json({ error: "tutorId is required" }, { status: 400 });

  const tutor = await loadTutor(supabase, tutorId, user.id);
  if (!tutor) return NextResponse.json({ error: "Tutor not found" }, { status: 404 });

  const { data: messages, error } = await supabase
    .from("chat_messages")
    .select("id, role, content, had_image, created_at")
    .eq("tutor_id", tutorId)
    .order("created_at", { ascending: true });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ tutor, messages });
}

export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const { data: student } = await supabase
    .from("students")
    .select("tier, tier_expires_at, timezone, curriculum_track, curriculum_level")
    .eq("id", user.id)
    .maybeSingle();
  if (!student) return NextResponse.json({ error: "Complete onboarding first" }, { status: 400 });

  const tier = effectiveTier(student.tier, student.tier_expires_at);

  const parsed = postSchema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const { tutorId, message, imageBase64, imageMimeType } = parsed.data;

  const tutor = await loadTutor(supabase, tutorId, user.id);
  if (!tutor) return NextResponse.json({ error: "Tutor not found" }, { status: 404 });

  const usage = await checkAndIncrementChatUsage(
    supabase,
    user.id,
    tier,
    student.timezone
  );
  if (!usage.allowed) {
    return NextResponse.json(
      {
        error: "Daily free-tier chat limit reached",
        used: usage.used,
        limit: usage.limit,
        upgradeUrl: "/subscription",
      },
      { status: 429 }
    );
  }

  const { data: priorMessages } = await supabase
    .from("chat_messages")
    .select("role, content")
    .eq("tutor_id", tutorId)
    .order("created_at", { ascending: false })
    .limit(HISTORY_TURNS);

  const history: ChatTurn[] = (priorMessages ?? [])
    .slice()
    .reverse()
    .map((m) => ({ role: m.role as "user" | "assistant", content: m.content }));

  const track = student.curriculum_track as CurriculumTrack | null;
  const systemInstruction =
    `You are ${tutor.name}, an AI study tutor for the subject "${tutor.subject}". ` +
    `${PERSONALITY_SYSTEM_HINT[tutor.personality as Personality]} ` +
    (track
      ? MARK_SCHEME_STYLE[track] + " "
      : "") +
    (tutor.language === "bn"
      ? "Reply primarily in Bengali (বাংলা), keeping technical/scientific terms in English where that's the convention. "
      : "Reply in English. ") +
    "Keep replies focused and under 200 words unless the student asks for a full worked solution. " +
    "When you write math, wrap inline expressions in single dollar signs like $x^2$ and " +
    "standalone equations in double dollar signs like $$x^2 + 1 = 0$$ so they render properly.";

  const userMessageForModel = message.trim().length > 0 ? message : "(see attached photo)";

  let reply: string;
  try {
    reply = await chatWithTutor({
      systemInstruction,
      history,
      message: userMessageForModel,
      imageBase64,
      imageMimeType,
    });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 500 });
  }

  const { error: insertError } = await supabase.from("chat_messages").insert([
    {
      student_id: user.id,
      tutor_id: tutorId,
      role: "user",
      content: userMessageForModel,
      had_image: Boolean(imageBase64),
    },
    { student_id: user.id, tutor_id: tutorId, role: "assistant", content: reply },
  ]);
  if (insertError) return NextResponse.json({ error: insertError.message }, { status: 500 });

  return NextResponse.json({ reply, usage });
}
