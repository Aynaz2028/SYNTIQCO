import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";

const bodySchema = z.object({
  fullName: z.string().min(1).max(120),
  track: z.enum(["nctb", "cambridge_edexcel"]),
  level: z.string().min(1),
  subjects: z.array(z.string()).min(1).max(10),
});

export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  const parsed = bodySchema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const { fullName, track, level, subjects } = parsed.data;

  const { error } = await supabase.from("students").upsert({
    id: user.id,
    full_name: fullName,
    curriculum_track: track,
    curriculum_level: level,
    subjects,
    onboarding_completed_at: new Date().toISOString(),
  });

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ ok: true });
}
