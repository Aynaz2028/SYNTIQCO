import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { solveQuestion } from "@/lib/gemini";
import { checkAndIncrementSolverUsage } from "@/lib/rate-limit";
import { logWeakPoint } from "@/lib/memory-engine";
import { effectiveTier } from "@/lib/tiers";
import type { CurriculumTrack } from "@/lib/curriculum";

const bodySchema = z
  .object({
    questionText: z.string().max(4000).optional().default(""),
    subjectHint: z.string().optional(),
    inputType: z.enum(["typed", "photo"]).default("typed"),
    wasFirstAttemptWrong: z.boolean().optional().default(false),
    imageBase64: z.string().optional(),
    imageMimeType: z.string().optional(),
  })
  .refine((v) => v.questionText.trim().length >= 3 || (v.imageBase64 && v.imageMimeType), {
    message: "Provide a typed question (min 3 chars) or a photo.",
  });

export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const { data: student } = await supabase
    .from("students")
    .select("tier, tier_expires_at, timezone, curriculum_track")
    .eq("id", user.id)
    .single();
  if (!student) return NextResponse.json({ error: "Complete onboarding first" }, { status: 400 });

  const tier = effectiveTier(student.tier, student.tier_expires_at);

  const parsed = bodySchema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const { questionText, subjectHint, inputType, wasFirstAttemptWrong, imageBase64, imageMimeType } =
    parsed.data;

  // Server-side enforcement — this is the real gate; the UI counter is
  // just a courtesy display and cannot be relied on by itself.
  const usage = await checkAndIncrementSolverUsage(
    supabase,
    user.id,
    tier,
    student.timezone
  );
  if (!usage.allowed) {
    return NextResponse.json(
      {
        error: "Daily free-tier Solver limit reached",
        used: usage.used,
        limit: usage.limit,
        upgradeUrl: "/subscription",
      },
      { status: 429 }
    );
  }

  try {
    const result = await solveQuestion({
      questionText,
      track: student.curriculum_track as CurriculumTrack,
      subjectHint,
      imageBase64,
      imageMimeType,
    });

    await supabase.from("solver_logs").insert({
      student_id: user.id,
      subject: result.topicGuess.subject,
      topic: result.topicGuess.topic,
      question_text: questionText.trim().length > 0 ? questionText : "(photo question)",
      input_type: inputType,
      was_first_attempt_wrong: wasFirstAttemptWrong,
      response_steps: result.steps,
    });

    // Every solved question the student got wrong first automatically
    // feeds the Knowledge Memory Engine.
    if (wasFirstAttemptWrong) {
      await logWeakPoint(supabase, {
        studentId: user.id,
        subject: result.topicGuess.subject,
        topic: result.topicGuess.topic,
        subtopic: result.topicGuess.subtopic,
        errorType: "conceptual_gap",
        source: "solver",
      });
    }

    return NextResponse.json({ result, usage });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 500 });
  }
}
