import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { effectiveTier, limitsFor } from "@/lib/tiers";

export async function GET() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const { data: student } = await supabase
    .from("students")
    .select("tier, tier_expires_at")
    .eq("id", user.id)
    .single();
  if (!student) return NextResponse.json({ error: "Complete onboarding first" }, { status: 400 });

  const tier = effectiveTier(student.tier, student.tier_expires_at);
  const limits = limitsFor(tier);

  let query = supabase
    .from("weak_points")
    .select("id, subject, topic, subtopic, error_type, decay_score, times_reviewed, created_at")
    .eq("student_id", user.id)
    .order("created_at", { ascending: false });

  // Server-side enforcement of the "3-day memory history visible" free-tier
  // limit — filtering happens in the query itself, not hidden client-side.
  if (limits.memoryHistoryDays !== Infinity) {
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - limits.memoryHistoryDays);
    query = query.gte("created_at", cutoff.toISOString());
  }

  const { data, error } = await query;
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  return NextResponse.json({
    weakPoints: data,
    tier,
    historyLimitDays: limits.memoryHistoryDays === Infinity ? null : limits.memoryHistoryDays,
  });
}
