import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function GET() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const { data } = await supabase
    .from("streaks")
    .select("current_streak, longest_streak, last_completed_date, badges")
    .eq("student_id", user.id)
    .maybeSingle();

  return NextResponse.json({
    streak: data ?? { current_streak: 0, longest_streak: 0, last_completed_date: null, badges: [] },
  });
}
