import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { submitVideoQuizAnswer } from "@/lib/video-lesson";

const bodySchema = z.object({
  lessonId: z.string().uuid(),
  questionIndex: z.number().int().min(0),
  question: z.string().min(1),
  subject: z.string().min(1),
  topic: z.string().min(1),
  isCorrect: z.boolean(),
});

export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const parsed = bodySchema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const body = parsed.data;

  try {
    const result = await submitVideoQuizAnswer(supabase, {
      studentId: user.id,
      lessonId: body.lessonId,
      questionIndex: body.questionIndex,
      question: body.question,
      subject: body.subject,
      topic: body.topic,
      isCorrect: body.isCorrect,
    });
    return NextResponse.json(result);
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 500 });
  }
}
