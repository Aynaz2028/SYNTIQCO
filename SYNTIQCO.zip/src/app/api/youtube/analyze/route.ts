import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { generateVideoLesson } from "@/lib/video-lesson";
import { checkAndIncrementYoutubeUsage } from "@/lib/rate-limit";
import { effectiveTier } from "@/lib/tiers";
import type { CurriculumTrack } from "@/lib/curriculum";

const bodySchema = z.object({
  url: z.string().min(1).max(500),
  subject: z.string().max(80).optional(),
});

export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const { data: student } = await supabase
    .from("students")
    .select("tier, tier_expires_at, timezone, curriculum_track")
    .eq("id", user.id)
    .single();
  if (!student) return NextResponse.json({ error: "Complete onboarding first" }, { status: 400 });

  const tier = effectiveTier(student.tier, student.tier_expires_at);

  const parsed = bodySchema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const { url, subject } = parsed.data;

  // Server-side enforcement — this is the real gate; the UI counter is
  // just a courtesy display and cannot be relied on by itself.
  const usage = await checkAndIncrementYoutubeUsage(
    supabase,
    user.id,
    tier,
    student.timezone
  );
  if (!usage.allowed) {
    return NextResponse.json(
      {
        error: "Daily free-tier YouTube Learning limit reached",
        used: usage.used,
        limit: usage.limit,
        upgradeUrl: "/subscription",
      },
      { status: 429 }
    );
  }

  try {
    const lesson = await generateVideoLesson(supabase, {
      studentId: user.id,
      url,
      subject: subject && subject.trim().length > 0 ? subject.trim() : "General",
      track: student.curriculum_track as CurriculumTrack,
    });

    return NextResponse.json({ lesson, usage });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 500 });
  }
}
