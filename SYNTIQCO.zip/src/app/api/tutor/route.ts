import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";

const bodySchema = z.object({
  name: z.string().min(1).max(40),
  subject: z.string().min(1).max(60),
  personality: z.enum(["encouraging", "strict", "funny", "socratic"]),
  voice: z.enum(["female", "male", "neutral"]),
  avatar: z.string().min(1).max(8),
  language: z.enum(["en", "bn"]),
});

export async function GET() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const { data, error } = await supabase
    .from("tutors")
    .select("id, name, subject, personality, voice, avatar, language, created_at")
    .eq("student_id", user.id)
    .order("created_at", { ascending: false });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ tutors: data });
}

export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const { data: student } = await supabase
    .from("students")
    .select("id")
    .eq("id", user.id)
    .maybeSingle();
  if (!student) return NextResponse.json({ error: "Complete onboarding first" }, { status: 400 });

  const parsed = bodySchema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const { data, error } = await supabase
    .from("tutors")
    .insert({ student_id: user.id, ...parsed.data })
    .select("id, name, subject, personality, voice, avatar, language, created_at")
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ tutor: data });
}
