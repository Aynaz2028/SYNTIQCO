import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { getSettings } from "@/lib/settings";

const patchSchema = z
  .object({
    theme: z.enum(["dark", "light", "system"]).optional(),
    language: z.enum(["en", "bn"]).optional(),
    showOnLeaderboard: z.boolean().optional(),
    shareProgressWithFriends: z.boolean().optional(),
    aiReminderNotifications: z.boolean().optional(),
    dailyMissionNotifications: z.boolean().optional(),
    friendActivityNotifications: z.boolean().optional(),
  })
  .refine((v) => Object.keys(v).length > 0, { message: "No fields to update" });

export async function GET() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const settings = await getSettings(supabase, user.id);
  return NextResponse.json({ settings });
}

export async function PATCH(request: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const parsed = patchSchema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  // Make sure a row exists before the partial update below.
  await getSettings(supabase, user.id);

  const patch: Record<string, string | boolean> = {};
  if (parsed.data.theme) patch.theme = parsed.data.theme;
  if (parsed.data.language) patch.language = parsed.data.language;
  if (parsed.data.showOnLeaderboard !== undefined)
    patch.show_on_leaderboard = parsed.data.showOnLeaderboard;
  if (parsed.data.shareProgressWithFriends !== undefined)
    patch.share_progress_with_friends = parsed.data.shareProgressWithFriends;
  if (parsed.data.aiReminderNotifications !== undefined)
    patch.ai_reminder_notifications = parsed.data.aiReminderNotifications;
  if (parsed.data.dailyMissionNotifications !== undefined)
    patch.daily_mission_notifications = parsed.data.dailyMissionNotifications;
  if (parsed.data.friendActivityNotifications !== undefined)
    patch.friend_activity_notifications = parsed.data.friendActivityNotifications;

  const { error } = await supabase
    .from("student_settings")
    .update({ ...patch, updated_at: new Date().toISOString() })
    .eq("student_id", user.id);

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  const response = NextResponse.json({ ok: true });

  // Mirror theme to a plain cookie so the server layout can pick the initial
  // `data-theme` attribute on next load without a flash of the wrong theme.
  if (parsed.data.theme) {
    response.cookies.set("hf-theme", parsed.data.theme, {
      path: "/",
      maxAge: 60 * 60 * 24 * 365,
      sameSite: "lax",
    });
  }

  return response;
}
