import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { findWeakPointsDueForAlert, markAlerted } from "@/lib/memory-engine";
import { sendPushToStudent, sendSmsStub } from "@/lib/notifications";

/**
 * Smart Retention Alerts — scheduled job (V1 scope).
 *
 * Not wired to a specific scheduler here since that's host-dependent
 * (Vercel Cron, Supabase Edge cron, a plain OS cron hitting this URL,
 * etc.) — point any scheduler at this route on an interval like every
 * 30-60 minutes, with header: Authorization: Bearer <CRON_SECRET>.
 *
 * SMS is stubbed per the V1 brief: sendSmsStub() only logs today. When
 * an MFS-region SMS provider is wired in V2, that's the only call site
 * that needs to change.
 */
export async function POST(request: Request) {
  const secret = process.env.CRON_SECRET;
  const authHeader = request.headers.get("authorization");
  if (!secret || authHeader !== `Bearer ${secret}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const supabase = createAdminClient();
  const due = await findWeakPointsDueForAlert(supabase);

  if (due.length === 0) {
    return NextResponse.json({ alerted: 0, students: 0 });
  }

  const byStudent = new Map<string, typeof due>();
  for (const wp of due) {
    const list = byStudent.get(wp.student_id) ?? [];
    list.push(wp);
    byStudent.set(wp.student_id, list);
  }

  const { data: students } = await supabase
    .from("students")
    .select("id, full_name, notification_phone")
    .in("id", Array.from(byStudent.keys()));
  const studentsById = new Map((students ?? []).map((s) => [s.id, s]));

  // Respect the "AI Reminder" toggle in Settings — students who turned it
  // off still accrue weak points and get re-alerted once they turn it back
  // on, but no push goes out while it's disabled.
  const { data: settingsRows } = await supabase
    .from("student_settings")
    .select("student_id, ai_reminder_notifications")
    .in("student_id", Array.from(byStudent.keys()));
  const optedOut = new Set(
    (settingsRows ?? [])
      .filter((s) => s.ai_reminder_notifications === false)
      .map((s) => s.student_id)
  );

  let alertedStudents = 0;
  const allAlertedIds: string[] = [];

  for (const [studentId, weakPoints] of byStudent) {
    if (optedOut.has(studentId)) {
      allAlertedIds.push(...weakPoints.map((wp) => wp.id));
      continue;
    }
    const top = weakPoints[0];
    const student = studentsById.get(studentId);
    const firstName = (student?.full_name ?? "there").split(" ")[0];

    const title = "Time to revisit a weak topic";
    const body =
      weakPoints.length === 1
        ? `${firstName}, ${top.subject} — ${top.topic} is due for a quick review before it fades.`
        : `${firstName}, ${weakPoints.length} topics (starting with ${top.subject} — ${top.topic}) are due for review.`;

    try {
      await sendPushToStudent(supabase, studentId, { title, body, url: "/dashboard" });
      if (student?.notification_phone) {
        await sendSmsStub(student.notification_phone, body);
      }
      alertedStudents += 1;
      allAlertedIds.push(...weakPoints.map((wp) => wp.id));
    } catch {
      // One student's failed notification (e.g. push provider hiccup)
      // shouldn't stop the rest of the batch from being processed.
    }
  }

  await markAlerted(supabase, allAlertedIds);

  return NextResponse.json({ alerted: allAlertedIds.length, students: alertedStudents });
}
