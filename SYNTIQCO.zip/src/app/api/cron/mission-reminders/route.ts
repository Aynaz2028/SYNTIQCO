import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { sendPushToStudent } from "@/lib/notifications";
import { studentLocalDate } from "@/lib/streak";

// Nudge at 8 PM in the student's own timezone — late enough that "haven't
// started yet" is a meaningful signal, early enough to still act on it.
const REMINDER_LOCAL_HOUR = 20;

function studentLocalHour(timezone: string): number {
  return Number(
    new Intl.DateTimeFormat("en-US", {
      timeZone: timezone,
      hour: "numeric",
      hour12: false,
    }).format(new Date())
  );
}

/**
 * Daily Mission reminder — scheduled job, companion to the Smart Retention
 * Alerts cron (`/api/cron/retention-alerts`). Same auth, same deployment
 * story: point a scheduler at this route roughly once an hour with
 * header Authorization: Bearer <CRON_SECRET>.
 *
 * Runs hourly (not once a day) because students span timezones — each
 * invocation only nudges students for whom it's currently
 * REMINDER_LOCAL_HOUR:00 locally. `mission_reminders_sent` is an
 * insert-once-per-day guard so an overlapping run in the same hour window
 * can't double-send.
 */
export async function POST(request: Request) {
  const secret = process.env.CRON_SECRET;
  const authHeader = request.headers.get("authorization");
  if (!secret || authHeader !== `Bearer ${secret}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const supabase = createAdminClient();

  const { data: optedIn, error: settingsError } = await supabase
    .from("student_settings")
    .select("student_id")
    .eq("daily_mission_notifications", true);
  if (settingsError) {
    return NextResponse.json({ error: settingsError.message }, { status: 500 });
  }
  if (!optedIn || optedIn.length === 0) {
    return NextResponse.json({ reminded: 0, checked: 0 });
  }

  const { data: students, error: studentsError } = await supabase
    .from("students")
    .select("id, full_name, timezone")
    .in(
      "id",
      optedIn.map((s) => s.student_id)
    );
  if (studentsError) {
    return NextResponse.json({ error: studentsError.message }, { status: 500 });
  }

  // Only students for whom it's currently REMINDER_LOCAL_HOUR:00 locally.
  const dueNow = (students ?? []).filter(
    (s) => s.timezone && studentLocalHour(s.timezone) === REMINDER_LOCAL_HOUR
  );
  if (dueNow.length === 0) {
    return NextResponse.json({ reminded: 0, checked: 0 });
  }

  const todayByStudent = new Map(dueNow.map((s) => [s.id, studentLocalDate(s.timezone)]));

  const { data: missions } = await supabase
    .from("daily_missions")
    .select("student_id, mission_date, completed_at")
    .in(
      "student_id",
      dueNow.map((s) => s.id)
    );
  const missionByStudentDate = new Map(
    (missions ?? []).map((m) => [`${m.student_id}:${m.mission_date}`, m])
  );

  let reminded = 0;
  for (const student of dueNow) {
    const today = todayByStudent.get(student.id)!;
    const mission = missionByStudentDate.get(`${student.id}:${today}`);
    if (mission?.completed_at) continue; // already finished today's mission

    // Claim today's reminder slot before sending — unique violation means
    // another (overlapping) run already handled this student today.
    const { error: claimError } = await supabase
      .from("mission_reminders_sent")
      .insert({ student_id: student.id, reminder_date: today });
    if (claimError) continue;

    const firstName = (student.full_name ?? "there").split(" ")[0];
    try {
      await sendPushToStudent(supabase, student.id, {
        title: "Today's mission is waiting",
        body: `${firstName}, you haven't finished today's mission yet — it's about 8 minutes. Start now?`,
        url: "/dashboard",
      });
      reminded += 1;
    } catch {
      // One student's failed push shouldn't stop the rest of the batch.
    }
  }

  return NextResponse.json({ reminded, checked: dueNow.length });
}
