import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { buildProfileData } from "@/lib/profile-stats";
import { effectiveTier } from "@/lib/tiers";

export async function GET() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const { data: student } = await supabase
    .from("students")
    .select(
      "full_name, curriculum_track, curriculum_level, subjects, tier, tier_expires_at, onboarding_completed_at"
    )
    .eq("id", user.id)
    .maybeSingle();

  if (!student?.onboarding_completed_at) {
    return NextResponse.json({ error: "Complete onboarding first" }, { status: 400 });
  }

  const profile = await buildProfileData(supabase, user.id);

  return NextResponse.json({
    student: {
      fullName: student.full_name,
      track: student.curriculum_track,
      level: student.curriculum_level,
      subjects: student.subjects,
      tier: effectiveTier(student.tier, student.tier_expires_at),
    },
    ...profile,
  });
}
