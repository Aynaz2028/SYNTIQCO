import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { getOrCreateTodaysMission } from "@/lib/mission";
import type { CurriculumTrack } from "@/lib/curriculum";

export async function GET() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const { data: student, error: studentError } = await supabase
    .from("students")
    .select("timezone, curriculum_track, subjects")
    .eq("id", user.id)
    .single();

  if (studentError || !student) {
    return NextResponse.json({ error: "Complete onboarding first" }, { status: 400 });
  }

  try {
    const mission = await getOrCreateTodaysMission(supabase, {
      studentId: user.id,
      timezone: student.timezone,
      track: student.curriculum_track as CurriculumTrack,
      subjects: student.subjects ?? [],
    });

    // Enrich with the actual weak-point text so the client can render
    // "Flashcard: Organic Chemistry > Nomenclature" without a second round trip.
    const weakPointIds = [mission.flashcard_weak_point_id, mission.quiz_weak_point_id].filter(
      Boolean
    ) as string[];

    let weakPointsById: Record<string, unknown> = {};
    if (weakPointIds.length > 0) {
      const { data: wps } = await supabase
        .from("weak_points")
        .select("id, subject, topic, subtopic")
        .in("id", weakPointIds);
      weakPointsById = Object.fromEntries((wps ?? []).map((wp) => [wp.id, wp]));
    }

    return NextResponse.json({ mission, weakPointsById });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 500 });
  }
}
