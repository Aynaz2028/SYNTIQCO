import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { completeMissionStep } from "@/lib/mission";
import { recordMissionCompletion } from "@/lib/streak";
import { logWeakPoint, markReviewed } from "@/lib/memory-engine";

const bodySchema = z.object({
  missionId: z.string().uuid(),
  step: z.enum(["review", "flashcard", "quiz", "mcq"]),
  weakPointId: z.string().uuid().nullable().optional(),
  isCorrect: z.boolean().optional(), // for quiz/mcq
  retained: z.boolean().optional(), // for flashcard self-assessment
  subject: z.string().optional(),
  topic: z.string().optional(),
  subtopic: z.string().nullable().optional(),
  question: z.string().optional(),
});

export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const parsed = bodySchema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const body = parsed.data;

  const { data: student } = await supabase
    .from("students")
    .select("timezone")
    .eq("id", user.id)
    .single();
  if (!student) return NextResponse.json({ error: "Complete onboarding first" }, { status: 400 });

  try {
    // Quiz/MCQ steps: log the attempt, and feed the memory engine on a miss.
    if (body.step === "quiz" || body.step === "mcq") {
      if (body.subject && body.topic && body.question && body.isCorrect !== undefined) {
        await supabase.from("quiz_logs").insert({
          student_id: user.id,
          subject: body.subject,
          topic: body.topic,
          subtopic: body.subtopic ?? null,
          question: body.question,
          is_correct: body.isCorrect,
        });

        if (!body.isCorrect) {
          await logWeakPoint(supabase, {
            studentId: user.id,
            subject: body.subject,
            topic: body.topic,
            subtopic: body.subtopic,
            errorType: "wrong_answer",
            source: body.step,
          });
        }
      }

      if (body.weakPointId) {
        await markReviewed(supabase, body.weakPointId, Boolean(body.isCorrect));
      }
    }

    // Weak Topic Review step: reading the re-teach note counts as a review
    // touch on that weak point (doesn't test recall, so always "retained").
    if (body.step === "review" && body.weakPointId) {
      await markReviewed(supabase, body.weakPointId, true);
    }

    // Flashcard step: self-reported retention adjusts decay directly.
    if (body.step === "flashcard" && body.weakPointId) {
      await markReviewed(supabase, body.weakPointId, body.retained ?? true);
    }

    const { allDone, completedSteps } = await completeMissionStep(
      supabase,
      body.missionId,
      body.step
    );

    let streak = null;
    if (allDone) {
      streak = await recordMissionCompletion(supabase, user.id, student.timezone);
    }

    return NextResponse.json({ completedSteps, allDone, streak });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 500 });
  }
}
