import { redirect } from "next/navigation";

// Item 15 replaced the two-tier Pro page with a proper Subscription screen
// (Free/Pro/VIP + Payment Options) at /subscription. This route stays in
// place so old links/bookmarks to /pro still land somewhere.
export default function ProPage() {
  redirect("/subscription");
}
