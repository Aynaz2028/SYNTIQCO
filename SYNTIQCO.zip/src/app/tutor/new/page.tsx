import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { TutorCreationContent } from "@/components/TutorCreationContent";

export default async function NewTutorPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: student } = await supabase
    .from("students")
    .select("onboarding_completed_at, subjects")
    .eq("id", user.id)
    .maybeSingle();
  if (!student?.onboarding_completed_at) redirect("/onboarding");

  return <TutorCreationContent subjects={student.subjects ?? []} />;
}
