import { redirect } from "next/navigation";
import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { AppNav } from "@/components/AppNav";
import { Button } from "@/components/Button";
import { PERSONALITIES } from "@/lib/tutor";

export default async function TutorListPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: student } = await supabase
    .from("students")
    .select("onboarding_completed_at")
    .eq("id", user.id)
    .maybeSingle();
  if (!student?.onboarding_completed_at) redirect("/onboarding");

  const { data: tutors } = await supabase
    .from("tutors")
    .select("id, name, subject, personality, avatar")
    .eq("student_id", user.id)
    .order("created_at", { ascending: false });

  return (
    <div className="min-h-screen">
      <AppNav active="tutor" />
      <div className="mx-auto max-w-2xl px-6 py-10">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-amber">AI Tutor</p>
            <h1 className="mt-1 font-display text-2xl italic">Your tutors</h1>
          </div>
          <Link href="/tutor/new">
            <Button>+ New tutor</Button>
          </Link>
        </div>

        {(!tutors || tutors.length === 0) && (
          <div className="paper mt-8 rounded-sm p-6 text-center text-sm text-ink-soft">
            You haven&apos;t created a tutor yet. Give it a name, a subject, and a personality —
            it&apos;ll remember every conversation you have.
          </div>
        )}

        <div className="mt-8 grid gap-3 sm:grid-cols-2">
          {tutors?.map((t) => (
            <Link
              key={t.id}
              href={`/chat/${t.id}`}
              className="paper flex items-center gap-4 rounded-sm p-5 transition-colors hover:border-ink/40"
            >
              <span className="text-3xl">{t.avatar}</span>
              <div>
                <p className="font-display text-lg">{t.name}</p>
                <p className="text-xs text-ink-soft">
                  {t.subject} ·{" "}
                  {PERSONALITIES.find((p) => p.value === t.personality)?.label ?? t.personality}
                </p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
