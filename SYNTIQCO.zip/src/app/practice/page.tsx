import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { AppNav } from "@/components/AppNav";
import { effectiveTier } from "@/lib/tiers";
import { PracticeContent } from "@/components/PracticeContent";

export default async function PracticePage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: student } = await supabase
    .from("students")
    .select("onboarding_completed_at, subjects, tier, tier_expires_at")
    .eq("id", user.id)
    .maybeSingle();

  if (!student?.onboarding_completed_at) redirect("/onboarding");

  const tier = effectiveTier(student.tier, student.tier_expires_at);

  return (
    <div className="min-h-screen">
      <AppNav active="practice" />
      <PracticeContent subjects={student.subjects ?? []} tier={tier} />
    </div>
  );
}
