import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { AppNav } from "@/components/AppNav";
import { SubscriptionContent } from "@/components/SubscriptionContent";
import { effectiveTier } from "@/lib/tiers";

export default async function SubscriptionPage({
  searchParams,
}: {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) {
  const params = await searchParams;
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: student } = await supabase
    .from("students")
    .select("onboarding_completed_at, tier, tier_expires_at")
    .eq("id", user.id)
    .maybeSingle();
  if (!student?.onboarding_completed_at) redirect("/onboarding");

  const { data: payments } = await supabase
    .from("subscription_payments")
    .select("id, tier, amount, payment_method, status, created_at")
    .eq("student_id", user.id)
    .order("created_at", { ascending: false })
    .limit(5);

  const tier = effectiveTier(student.tier, student.tier_expires_at);

  const status =
    params.success === "1"
      ? ("success" as const)
      : params.pending === "1"
        ? ("pending" as const)
        : params.canceled === "1"
          ? ("canceled" as const)
          : params.error
            ? ("error" as const)
            : null;

  return (
    <div className="min-h-screen">
      <AppNav active="subscription" />
      <SubscriptionContent
        currentTier={tier}
        tierExpiresAt={tier === "free" ? null : student.tier_expires_at}
        payments={payments ?? []}
        initialStatus={status}
      />
    </div>
  );
}
