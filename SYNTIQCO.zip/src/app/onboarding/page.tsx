"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/Button";
import { CURRICULUM_LEVELS, SUBJECTS_BY_LEVEL, type CurriculumTrack } from "@/lib/curriculum";

export default function OnboardingPage() {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [fullName, setFullName] = useState("");
  const [track, setTrack] = useState<CurriculumTrack | null>(null);
  const [level, setLevel] = useState<string | null>(null);
  const [subjects, setSubjects] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const availableSubjects = level ? SUBJECTS_BY_LEVEL[level] : [];

  function toggleSubject(subject: string) {
    setSubjects((prev) =>
      prev.includes(subject) ? prev.filter((s) => s !== subject) : [...prev, subject]
    );
  }

  async function finish() {
    if (!track || !level || subjects.length === 0 || !fullName.trim()) return;
    setSubmitting(true);
    setError(null);
    const res = await fetch("/api/onboarding", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fullName, track, level, subjects }),
    });
    setSubmitting(false);
    if (!res.ok) {
      const body = await res.json();
      setError(body.error?.formErrors?.join(", ") ?? "Something went wrong. Try again.");
      return;
    }
    router.replace("/dashboard");
    router.refresh();
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-xl flex-col justify-center px-6 py-16">
      <p className="font-mono text-xs uppercase tracking-widest text-amber">
        Step {step + 1} of 4
      </p>

      {step === 0 && (
        <div className="mt-4">
          <h1 className="font-display text-2xl">What should we call you?</h1>
          <input
            autoFocus
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            placeholder="Your name"
            className="mt-6 w-full rounded-sm border border-rule-dark bg-transparent px-3 py-2 outline-none focus:border-amber"
          />
          <Button
            className="mt-8"
            disabled={!fullName.trim()}
            onClick={() => setStep(1)}
          >
            Continue
          </Button>
        </div>
      )}

      {step === 1 && (
        <div className="mt-4">
          <h1 className="font-display text-2xl">Which curriculum are you following?</h1>
          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            {(
              [
                { value: "nctb", label: "NCTB", sub: "SSC / HSC — Bangladesh board" },
                {
                  value: "cambridge_edexcel",
                  label: "Cambridge / Edexcel",
                  sub: "O Level / A Level",
                },
              ] as const
            ).map((opt) => (
              <button
                key={opt.value}
                onClick={() => {
                  setTrack(opt.value);
                  setLevel(null);
                  setSubjects([]);
                }}
                className={`rounded-sm border p-5 text-left transition-colors ${
                  track === opt.value
                    ? "border-amber bg-amber/10"
                    : "border-rule-dark hover:border-paper/40"
                }`}
              >
                <p className="font-display text-lg">{opt.label}</p>
                <p className="mt-1 text-xs text-paper/60">{opt.sub}</p>
              </button>
            ))}
          </div>
          <div className="mt-8 flex gap-3">
            <Button variant="ghost" onClick={() => setStep(0)}>
              Back
            </Button>
            <Button disabled={!track} onClick={() => setStep(2)}>
              Continue
            </Button>
          </div>
        </div>
      )}

      {step === 2 && track && (
        <div className="mt-4">
          <h1 className="font-display text-2xl">Which level?</h1>
          <div className="mt-6 flex flex-wrap gap-3">
            {CURRICULUM_LEVELS[track].map((opt) => (
              <button
                key={opt.value}
                onClick={() => {
                  setLevel(opt.value);
                  setSubjects([]);
                }}
                className={`rounded-full border px-5 py-2 text-sm transition-colors ${
                  level === opt.value
                    ? "border-amber bg-amber/10 text-amber"
                    : "border-rule-dark hover:border-paper/40"
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
          <div className="mt-8 flex gap-3">
            <Button variant="ghost" onClick={() => setStep(1)}>
              Back
            </Button>
            <Button disabled={!level} onClick={() => setStep(3)}>
              Continue
            </Button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="mt-4">
          <h1 className="font-display text-2xl">Pick your subjects</h1>
          <div className="mt-6 flex flex-wrap gap-3">
            {availableSubjects.map((subject) => (
              <button
                key={subject}
                onClick={() => toggleSubject(subject)}
                className={`rounded-full border px-4 py-2 text-sm transition-colors ${
                  subjects.includes(subject)
                    ? "border-amber bg-amber/10 text-amber"
                    : "border-rule-dark hover:border-paper/40"
                }`}
              >
                {subject}
              </button>
            ))}
          </div>
          {error && <p className="mt-4 text-sm text-red">{error}</p>}
          <div className="mt-8 flex gap-3">
            <Button variant="ghost" onClick={() => setStep(2)}>
              Back
            </Button>
            <Button disabled={subjects.length === 0 || submitting} onClick={finish}>
              {submitting ? "Setting up…" : "Start my first mission"}
            </Button>
          </div>
        </div>
      )}
    </main>
  );
}
