import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getVapidPublicKey } from "@/lib/notifications";
import { AppNav } from "@/components/AppNav";
import { DashboardContent } from "@/components/DashboardContent";

export default async function DashboardPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: student } = await supabase
    .from("students")
    .select("onboarding_completed_at")
    .eq("id", user.id)
    .maybeSingle();

  if (!student?.onboarding_completed_at) redirect("/onboarding");

  const { data: streak } = await supabase
    .from("streaks")
    .select("current_streak, longest_streak, badges")
    .eq("student_id", user.id)
    .maybeSingle();

  return (
    <div className="min-h-screen">
      <AppNav active="dashboard" />
      <DashboardContent
        initialStreak={
          streak ?? { current_streak: 0, longest_streak: 0, badges: [] as string[] }
        }
        vapidPublicKey={getVapidPublicKey()}
      />
    </div>
  );
}
