import Link from "next/link";
import { Button } from "@/components/Button";
import { MarginMark } from "@/components/MarginMark";

export default function LandingPage() {
  return (
    <main className="flex-1">
      {/* Nav */}
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <span className="font-display text-xl italic">HabitFirst</span>
        <nav className="flex items-center gap-3">
          <Link href="/login" className="text-sm text-paper/70 hover:text-paper">
            Log in
          </Link>
          <Link href="/signup">
            <Button variant="primary" className="!px-5 !py-2 text-xs">
              Start free
            </Button>
          </Link>
        </nav>
      </header>

      {/* Hero */}
      <section className="mx-auto grid max-w-6xl gap-12 px-6 pb-24 pt-8 md:grid-cols-2 md:items-center">
        <div>
          <p className="mb-4 font-mono text-xs uppercase tracking-[0.2em] text-amber">
            NCTB · Cambridge · Edexcel
          </p>
          <h1 className="font-display text-4xl leading-[1.1] md:text-5xl">
            The AI study companion that{" "}
            <span className="italic text-amber">remembers</span> every mistake you make —
            so you don&apos;t make it twice.
          </h1>
          <p className="mt-6 max-w-md text-paper/70">
            HabitFirst logs every wrong answer into a persistent Knowledge Memory Engine, then
            builds a 4-step, under-8-minute mission each day to fix exactly what you&apos;re weak
            on — for SSC/HSC and O/A Level students.
          </p>
          <div className="mt-8 flex items-center gap-4">
            <Link href="/signup">
              <Button variant="primary">Build your streak today</Button>
            </Link>
            <span className="font-mono text-xs text-paper/50">Free tier · 5 solves/day</span>
          </div>
        </div>

        {/* Signature element: a "returned script" with margin marks that
            resolve into the memory engine's weak-point cards */}
        <div className="paper relative rounded-sm p-6 pl-12 shadow-2xl shadow-black/40 md:-rotate-1">
          <div className="mb-4 flex items-center justify-between font-mono text-xs text-ink-soft">
            <span>Organic Chemistry — Script 04</span>
            <span>SSC · Board Paper</span>
          </div>

          <p className="relative mb-3 leading-8">
            <span className="absolute -left-8 top-0">
              <MarginMark label="✕" />
            </span>
            Nomenclature of branched alkanes — longest chain misidentified.
          </p>
          <p className="relative mb-3 leading-8 text-ink-soft">
            <span className="absolute -left-8 top-0">
              <MarginMark label="M1" variant="green" />
            </span>
            Correct method for functional group priority, arithmetic slip in step 3.
          </p>

          <div className="mt-6 rounded-sm border border-rule bg-bg-ink/[0.03] p-4">
            <p className="font-mono text-[11px] uppercase tracking-wide text-ink-soft">
              Logged to memory engine
            </p>
            <p className="mt-2 font-display italic">
              &ldquo;You made 2 mistakes in Organic Chemistry last Tuesday. Let&apos;s do a
              3-minute quiz on those exact weak points today.&rdquo;
            </p>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="border-t border-rule-dark bg-bg-ink-soft/40 py-20">
        <div className="mx-auto max-w-6xl px-6">
          <h2 className="font-display text-2xl italic">A habit loop, not a chatbot</h2>
          <div className="mt-10 grid gap-8 md:grid-cols-3">
            {[
              {
                mark: "M1",
                title: "It remembers",
                body:
                  "Every wrong answer — from a quiz, the solver, or a past paper MCQ — is logged with subject, topic, and error type into your personal memory engine.",
              },
              {
                mark: "A1",
                title: "It greets you with context",
                body:
                  "Log in and get a real, specific line about what you got wrong recently — not a generic streak nudge.",
              },
              {
                mark: "✓",
                title: "It builds the habit",
                body:
                  "A 4-step daily mission — weak-topic review, flashcard, weak-topic quiz, past-paper MCQ, all AI-generated — under 8 minutes, with streaks and milestone badges.",
              },
            ].map((item) => (
              <div key={item.title} className="rounded-sm border border-rule-dark p-6">
                <MarginMark label={item.mark} variant={item.mark === "✓" ? "green" : "red"} />
                <h3 className="mt-4 font-display text-lg">{item.title}</h3>
                <p className="mt-2 text-sm text-paper/70">{item.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Curriculum tracks */}
      <section className="mx-auto max-w-6xl px-6 py-20">
        <h2 className="font-display text-2xl italic">Built for two exam systems</h2>
        <div className="mt-8 grid gap-6 md:grid-cols-2">
          <div className="paper rounded-sm p-6">
            <p className="font-mono text-xs uppercase tracking-wide text-ink-soft">Track A</p>
            <h3 className="mt-1 font-display text-xl">NCTB — SSC &amp; HSC</h3>
            <p className="mt-2 text-sm text-ink-soft">
              Step-by-step solutions styled after NCTB board-marking conventions.
            </p>
          </div>
          <div className="paper rounded-sm p-6">
            <p className="font-mono text-xs uppercase tracking-wide text-ink-soft">Track B</p>
            <h3 className="mt-1 font-display text-xl">Cambridge &amp; Edexcel — O/A Level</h3>
            <p className="mt-2 text-sm text-ink-soft">
              Explanations that speak in M1/A1/B1 mark-scheme logic, the way examiners do.
            </p>
          </div>
        </div>
      </section>

      <footer className="border-t border-rule-dark px-6 py-8 text-center text-xs text-paper/40">
        HabitFirst · Pro upgrade coming soon — ৳99/mo
      </footer>
    </main>
  );
}
