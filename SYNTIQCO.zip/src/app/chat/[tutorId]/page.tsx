import { redirect, notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { AppNav } from "@/components/AppNav";
import { ChatContent } from "@/components/ChatContent";

export default async function ChatPage({
  params,
}: {
  params: Promise<{ tutorId: string }>;
}) {
  const { tutorId } = await params;
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: student } = await supabase
    .from("students")
    .select("onboarding_completed_at")
    .eq("id", user.id)
    .maybeSingle();
  if (!student?.onboarding_completed_at) redirect("/onboarding");

  const { data: tutor } = await supabase
    .from("tutors")
    .select("id, name, subject, personality, voice, avatar, language")
    .eq("id", tutorId)
    .eq("student_id", user.id)
    .maybeSingle();
  if (!tutor) notFound();

  const { data: messages } = await supabase
    .from("chat_messages")
    .select("id, role, content, had_image, created_at")
    .eq("tutor_id", tutorId)
    .order("created_at", { ascending: true });

  return (
    <div className="flex min-h-screen flex-col">
      <AppNav active="tutor" />
      <ChatContent tutor={tutor} initialMessages={messages ?? []} />
    </div>
  );
}
